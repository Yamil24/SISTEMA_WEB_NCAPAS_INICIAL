﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;

namespace CapaDatos
{
    public class AlumnoUsuarioCD
    {
        public bool LoguearAlumno(string usuarioIngresado, string claveIngresada)
        {
            bool loguear;

            ConexionCD conexionCD = new ConexionCD();
            SqlConnection cnx = conexionCD.ConexionToBD();
            cnx.Open();

            string sql = "SELECT * FROM apoderado WHERE apo_Usuario = @APO_USUARIO AND apo_Clave = dbo.fun_encriptarClave(@APO_Clave)";
            SqlCommand cmd = new SqlCommand(sql, cnx);
            cmd.Parameters.AddWithValue("@APO_USUARIO", usuarioIngresado);
            cmd.Parameters.AddWithValue("@APO_CLAVE", claveIngresada);
            using (SqlDataAdapter da = new SqlDataAdapter(cmd))
            {
                DataTable dt = new DataTable();

                da.Fill(dt);
                if (dt.Rows.Count == 0)
                {
                    loguear = false;
                }
                else
                {
                    loguear = true;
                }
            }

            cnx.Close();

            return loguear;
        }
    }
}
