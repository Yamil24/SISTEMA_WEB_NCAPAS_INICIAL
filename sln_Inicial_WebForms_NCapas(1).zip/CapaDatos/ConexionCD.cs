﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;

namespace CapaDatos
{
    public class ConexionCD
    {
        public SqlConnection ConexionToBD()
        {
            SqlConnectionStringBuilder generadorCadena = new SqlConnectionStringBuilder();

            generadorCadena.DataSource = "LocalHost";
            generadorCadena.InitialCatalog = "inicialDB";
            generadorCadena.UserID = "sa";
            generadorCadena.Password = "root";

            string cadenaCnx = generadorCadena.ConnectionString;

            SqlConnection cnx = new SqlConnection(cadenaCnx);

            return cnx;
        }
    }
}
