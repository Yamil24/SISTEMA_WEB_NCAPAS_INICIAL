﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;

using CapaEntidad;

namespace CapaDatos
{
    public class ProfesorCD
    {
        public bool LoguearProfesor(string usuarioIngresado, string claveIngresada)
        {
            bool loguear;

            ConexionCD conexionCD = new ConexionCD();
            SqlConnection cnx = conexionCD.ConexionToBD();
            cnx.Open();

            string sql = "SELECT * FROM profesor WHERE pro_Usuario = @PRO_USUARIO AND pro_Clave = dbo.fun_encriptarClave(@PRO_CLAVE)";
            SqlCommand cmd = new SqlCommand(sql, cnx);
            cmd.Parameters.AddWithValue("@PRO_USUARIO", usuarioIngresado);
            cmd.Parameters.AddWithValue("@PRO_CLAVE", claveIngresada);
            using (SqlDataAdapter da = new SqlDataAdapter(cmd))
            {
                DataTable dt = new DataTable();

                da.Fill(dt);
                if (dt.Rows.Count == 0)
                {
                    loguear = false;
                }
                else
                {
                    loguear = true;
                }
            }

            //Cerrar la conexion
            cnx.Close();

            return loguear;
        }

        public List<GrupoRegistroCE> listarRegistro(string grupoId, string areaId)
        {
            ConexionCD conexionCD = new ConexionCD();
            SqlConnection cnx = conexionCD.ConexionToBD();
            cnx.Open();

            SqlCommand cmd = cnx.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM vistaRegistro WHERE grupoId = @GRUPOID AND areaId = @AREAID";

            cmd.Parameters.AddWithValue("@GRUPOID", grupoId);
            cmd.Parameters.AddWithValue("@AREAID", areaId);

            SqlDataReader drRegistro = cmd.ExecuteReader();

            string gru_Id;
            string are_Id;
            string alu_Id;
            string alu_Nombre;
            string alu_Apellido;
            decimal dr_Nota1;
            decimal dr_Nota2;
            decimal dr_Nota3;
            decimal dr_Nota4;

            List<GrupoRegistroCE> listaGrupoRegistro = new List<GrupoRegistroCE>();

            while (drRegistro.Read())
            {
                gru_Id = drRegistro["grupoId"].ToString();
                are_Id = drRegistro["areaId"].ToString();
                alu_Id = drRegistro["codigo"].ToString();
                alu_Nombre = drRegistro["nombre"].ToString();
                alu_Apellido = drRegistro["apellido"].ToString();
                dr_Nota1 = Convert.ToDecimal(drRegistro["nota1"].ToString());
                dr_Nota2 = Convert.ToDecimal(drRegistro["nota2"].ToString());
                dr_Nota3 = Convert.ToDecimal(drRegistro["nota3"].ToString());
                dr_Nota4 = Convert.ToDecimal(drRegistro["nota4"].ToString());

                GrupoRegistroCE grupoRegistroCE = new GrupoRegistroCE(gru_Id, are_Id, alu_Id, alu_Nombre, alu_Apellido, dr_Nota1, dr_Nota2, dr_Nota3, dr_Nota4);

                listaGrupoRegistro.Add(grupoRegistroCE);
            }

            cnx.Close();

            return listaGrupoRegistro;
        }

        public void insertarDetalleRegistro(DetalleRegistroCE detalleRegistroCE)
        {
            ConexionCD conexionCD = new ConexionCD();
            SqlConnection cnx = conexionCD.ConexionToBD();
            cnx.Open();

            SqlCommand cmd = cnx.CreateCommand();

            cmd.CommandType = CommandType.Text;

            cmd.CommandText = ("INSERT INTO detalleRegistro(reg_Id,alu_Id,dr_Unidad1,dr_Unidad2,dr_Unidad3," +
                "dr_Unidad4,dr_PromedioFinal,dr_Calificacion,dr_Observacion)" +
                " VALUES(@reg_Id,@alu_Id,@dr_Unidad1,@dr_Unidad2,@dr_Unidad3," +
                "@dr_Unidad4,@dr_PromedioFinal,@dr_Calificacion,@dr_Observacion)");

            SqlParameter sql = new SqlParameter();

            cmd.Parameters.AddWithValue("@reg_Id", detalleRegistroCE.RegId);
            cmd.Parameters.AddWithValue("@alu_Id", detalleRegistroCE.AluId);
            cmd.Parameters.AddWithValue("@dr_Unidad1", detalleRegistroCE.DrUnidad1);
            cmd.Parameters.AddWithValue("@dr_Unidad2", detalleRegistroCE.DrUnidad2);
            cmd.Parameters.AddWithValue("@dr_Unidad3", detalleRegistroCE.DrUnidad3);
            cmd.Parameters.AddWithValue("@dr_Unidad4", detalleRegistroCE.DrUnidad4);
            cmd.Parameters.AddWithValue("@dr_PromedioFinal", detalleRegistroCE.PromedioFinal);
            cmd.Parameters.AddWithValue("@dr_Calificacion", detalleRegistroCE.Calificacion);
            cmd.Parameters.AddWithValue("@dr_Observacion", detalleRegistroCE.Observacion);

            cmd.ExecuteNonQuery();

            cnx.Close();
        }

        public void actualizarRegistro(DetalleRegistroCE detalleRegistroCE)
        {

            ConexionCD conexionCD = new ConexionCD();

            SqlConnection cnx = conexionCD.ConexionToBD();

            cnx.Open();

            SqlCommand cmd = cnx.CreateCommand();

            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "UPDATE detalleRegistro SET reg_Id=@reg_Id,alu_Id=@alu_Id, dr_Unidad1=@dr_Unidad1, dr_Unidad2=@dr_Unidad2,"
                + "dr_Unidad3=@dr_Unidad3, dr_Unidad4=@dr_Unidad4, dr_PromedioFinal=dbo.fun_promediar(@dr_Unidad1, @dr_Unidad2, @dr_Unidad3, @dr_Unidad4), dr_Calificacion= @dr_Calificacion, "
                  + "dr_Observacion=@dr_Observacion WHERE alu_Id=@alu_Id";


            cmd.Parameters.AddWithValue("@reg_Id", detalleRegistroCE.RegId);
            cmd.Parameters.AddWithValue("@alu_Id", detalleRegistroCE.AluId);
            cmd.Parameters.AddWithValue("@dr_Unidad1", detalleRegistroCE.DrUnidad1);
            cmd.Parameters.AddWithValue("@dr_Unidad2", detalleRegistroCE.DrUnidad2);
            cmd.Parameters.AddWithValue("@dr_Unidad3", detalleRegistroCE.DrUnidad3);
            cmd.Parameters.AddWithValue("@dr_Unidad4", detalleRegistroCE.DrUnidad4);
            cmd.Parameters.AddWithValue("@dr_PromedioFinal", detalleRegistroCE.PromedioFinal);
            cmd.Parameters.AddWithValue("@dr_Calificacion", detalleRegistroCE.Calificacion);
            cmd.Parameters.AddWithValue("@dr_Observacion", detalleRegistroCE.Observacion);

            cmd.ExecuteNonQuery();

            cnx.Close();
        }
    }
}
