﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;

using CapaEntidad;

namespace CapaDatos
{
    public class AdministradorUsuarioCD
    {
        //ADMINISTRADOR
        public bool LoguearAdministrador(string usuarioIngresado, string claveIngresada)
        {
            bool loguear;

            ConexionCD conexionCD = new ConexionCD();
            SqlConnection cnx = conexionCD.ConexionToBD();
            cnx.Open();

            string sql = "SELECT * FROM administrador WHERE adm_Usuario = @ADM_USUARIO AND adm_Clave = dbo.fun_encriptarClave(@ADM_Clave)";
            SqlCommand cmd = new SqlCommand(sql, cnx);
            cmd.Parameters.AddWithValue("@ADM_USUARIO", usuarioIngresado);
            cmd.Parameters.AddWithValue("@ADM_CLAVE", claveIngresada);
            using (SqlDataAdapter da = new SqlDataAdapter(cmd))
            {
                DataTable dt = new DataTable();

                da.Fill(dt);
                if (dt.Rows.Count == 0)
                {
                    loguear = false;
                }
                else
                {
                    loguear = true;
                }
            }
            //Cerrar la conexion
            cnx.Close();

            return loguear;
        }

        //APODERADO
        public void insertarApoderado(ApoderadoCE apoderadoCE)
        {
            ConexionCD conexionCD = new ConexionCD();
            SqlConnection cnx = conexionCD.ConexionToBD();
            cnx.Open();

            //Poner procedure
            SqlCommand cmd = new SqlCommand("sp_insertarApoderado", cnx);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlParameter sql = new SqlParameter();

            cmd.Parameters.AddWithValue("@apo_Dni", apoderadoCE.Dni);
            cmd.Parameters.AddWithValue("@apo_Nombre", apoderadoCE.Nombre);
            cmd.Parameters.AddWithValue("@apo_Apellido", apoderadoCE.Apellido);
            cmd.Parameters.AddWithValue("@apo_FechaNacimiento", apoderadoCE.FechaNac);
            cmd.Parameters.AddWithValue("@apo_Direccion", apoderadoCE.Direccion);
            cmd.Parameters.AddWithValue("@apo_Telefono", apoderadoCE.Telefono);
            cmd.Parameters.AddWithValue("@apo_Movil", apoderadoCE.Movil);
            cmd.Parameters.AddWithValue("@apo_CorreoPersonal", apoderadoCE.CorreoPersonal);
            cmd.Parameters.AddWithValue("@apo_Clave", apoderadoCE.Clave);

            cmd.ExecuteNonQuery();

            cnx.Close();
        }

        public void eliminarApoderado(ApoderadoCE apoderadoCE)
        {
            ConexionCD conexionCD = new ConexionCD();
            SqlConnection cnx = conexionCD.ConexionToBD();
            cnx.Open();

            SqlCommand cmd = cnx.CreateCommand();

            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "DELETE FROM apoderado WHERE apo_Dni=@apo_Dni";
            cmd.Parameters.AddWithValue("@apo_Dni", apoderadoCE.Dni);

            cmd.ExecuteNonQuery();

            cnx.Close();
        }

        public List<ApoderadoCE> buscarbyNombreApoderado(string buscarName)
        {

            ConexionCD conexionCD = new ConexionCD();
            SqlConnection cnx = conexionCD.ConexionToBD();
            cnx.Open();

            SqlCommand cmd = cnx.CreateCommand();

            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "SELECT * FROM apoderado WHERE apo_Nombre LIKE '%' + @apo_nombre + '%' ";
            cmd.Parameters.AddWithValue("@apo_nombre",buscarName);

            SqlDataReader drApoderad0 = cmd.ExecuteReader();

            string dni;
            string nombre;
            string apellido;
            DateTime fechaNac;
            string direccion;
            string telefono;
            string movil;
            string correoPersonal;
            string usuario;
            string clave;

            List<ApoderadoCE> listaApo = new List<ApoderadoCE>();
            while (drApoderad0.Read())
            {
                dni = drApoderad0["apo_Dni"].ToString();
                nombre = drApoderad0["apo_Nombre"].ToString();
                apellido = drApoderad0["apo_Apellido"].ToString();
                fechaNac = Convert.ToDateTime(drApoderad0["apo_FechaNacimiento"].ToString());
                direccion = drApoderad0["apo_Direccion"].ToString();
                telefono = drApoderad0["apo_Telefono"].ToString();
                movil = drApoderad0["apo_Movil"].ToString();
                correoPersonal = drApoderad0["apo_CorreoPersonal"].ToString();
                usuario = drApoderad0["apo_Usuario"].ToString();
                clave = drApoderad0["apo_Clave"].ToString();

                ApoderadoCE apoderadoCE = new ApoderadoCE(dni, nombre, apellido, fechaNac, direccion, telefono, movil, correoPersonal, usuario, clave);

                listaApo.Add(apoderadoCE);
            }
            cnx.Close();
            return listaApo;
        }

        public void actualizarApoderado(ApoderadoCE apoderadoCE)
        {
            ConexionCD conexionCD = new ConexionCD();
            SqlConnection cnx = conexionCD.ConexionToBD();
            cnx.Open();

            SqlCommand cmd = cnx.CreateCommand();

            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "UPDATE apoderado SET apo_Nombre=@apo_nombre, apo_Apellido=@apo_apellido, apo_FechaNacimiento=@apo_fechNacimineto," +
                "apo_Direccion=@apo_Direccion, apo_Telefono=@apo_Telefono, apo_Movil=@apo_Movil, apo_CorreoPersonal= @apo_correoPersonal," +
                "apo_Usuario=dbo.fun_generarUsuario(@nombre,@apellido,@apo_Dni), apo_Clave=dbo.fun_encriptarClave(@clave) WHERE apo_Dni=@apo_Dni";

            cmd.Parameters.AddWithValue("@apo_nombre", apoderadoCE.Nombre);
            cmd.Parameters.AddWithValue("@apo_apellido", apoderadoCE.Apellido);
            cmd.Parameters.AddWithValue("@apo_fechNacimineto", apoderadoCE.FechaNac);
            cmd.Parameters.AddWithValue("@apo_Direccion", apoderadoCE.Direccion);
            cmd.Parameters.AddWithValue("@apo_Telefono", apoderadoCE.Telefono);
            cmd.Parameters.AddWithValue("@apo_Movil", apoderadoCE.Movil);
            cmd.Parameters.AddWithValue("@apo_correo", apoderadoCE.CorreoPersonal);
            cmd.Parameters.AddWithValue("@apo_clave", apoderadoCE.Clave);
            cmd.Parameters.AddWithValue("@apo_Dni", apoderadoCE.Dni);

            cmd.ExecuteNonQuery();
            cnx.Close();
        }

        //REFERENTE
        public void insertarReferente(ReferenteCE referenteCE)
        {
            ConexionCD conexionCD = new ConexionCD();
            SqlConnection cnx = conexionCD.ConexionToBD();
            cnx.Open();

            SqlCommand cmd = new SqlCommand("sp_insertarReferente", cnx);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlParameter sql = new SqlParameter();
            cmd.Parameters.AddWithValue("@ref_Dni", referenteCE.Dni);
            cmd.Parameters.AddWithValue("@ref_Nombre", referenteCE.Nombre);
            cmd.Parameters.AddWithValue("@ref_Apellido", referenteCE.Apellido);
            cmd.Parameters.AddWithValue("@ref_FechaNacimiento", referenteCE.FechaNac);
            cmd.Parameters.AddWithValue("@ref_Direccion", referenteCE.Direccion);
            cmd.Parameters.AddWithValue("@ref_Telefono", referenteCE.Telefono);
            cmd.Parameters.AddWithValue("@ref_Movil", referenteCE.Movil);
            cmd.Parameters.AddWithValue("@ref_Correo", referenteCE.Correo);

            cmd.ExecuteNonQuery();

            cnx.Close();
        }

        public void eliminarReferente(ReferenteCE referenteCE)
        {
            ConexionCD conexionCD = new ConexionCD();
            SqlConnection cnx = conexionCD.ConexionToBD();
            cnx.Open();

            SqlCommand cmd = cnx.CreateCommand();

            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "DELETE FROM apoderado WHERE ref_Dni=@ref_Dni";
            cmd.Parameters.AddWithValue("@ref_Dni", referenteCE.Dni);

            cmd.ExecuteNonQuery();

            cnx.Close();
        }

        public List<ReferenteCE> buscarNombReferente(string nombreRef)
        {

            ConexionCD conexionCD = new ConexionCD();
            SqlConnection cnx = conexionCD.ConexionToBD();
            cnx.Open();

            SqlCommand cmd = cnx.CreateCommand();

            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "SELECT * FROM referente WHERE ref_Nombre LIKE '%' + @ref_nombre + '%' ";
            cmd.Parameters.AddWithValue("@ref_nombre", nombreRef);

            SqlDataReader drReferente = cmd.ExecuteReader();

            string dni;
            string nombre;
            string apellido;
            DateTime fechaNac;
            string direccion;
            string telefono;
            string movil;
            string correo;

            List<ReferenteCE> listaReferentes = new List<ReferenteCE>();
            while (drReferente.Read())
            {
                dni = drReferente["ref_Dni"].ToString();
                nombre = drReferente["ref_Nombre"].ToString();
                apellido = drReferente["ref_Apellido"].ToString();
                fechaNac = Convert.ToDateTime(drReferente["ref_FechaNacimiento"].ToString());
                direccion = drReferente["ref_Direccion"].ToString();
                telefono = drReferente["ref_Telefono"].ToString();
                movil = drReferente["ref_Movil"].ToString();
                correo = drReferente["ref_Correo"].ToString();

                ReferenteCE referenteCE = new ReferenteCE(dni, nombre, apellido, fechaNac, direccion, telefono, movil, correo);

                listaReferentes.Add(referenteCE);

            }
            cnx.Close();

            return listaReferentes;
        }

        public void actualizarReferente(ReferenteCE referenteCE)
        {
            ConexionCD conexionCD = new ConexionCD();
            SqlConnection cnx = conexionCD.ConexionToBD();
            cnx.Open();

            SqlCommand cmd = cnx.CreateCommand();

            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "UPDATE referente SET ref_Nombre=@ref_Nombre, ref_Apellido=@ref_Apellido, ref_FechaNacimiento=@ref_FechaNacimiento,"
                + "ref_Direccion=@ref_Direccion, ref_Telefono=@ref_Telefono, ref_Movil=@ref_Movil, ref_Correo=@ref_Correo, WHERE ref_Dni=@ref_Dni";

            cmd.Parameters.AddWithValue("@ref_nombre", referenteCE.Nombre);
            cmd.Parameters.AddWithValue("@ref_apellido", referenteCE.Apellido);
            cmd.Parameters.AddWithValue("@ref_fechNacimineto", referenteCE.FechaNac);

            cmd.Parameters.AddWithValue("@ref_direccion", referenteCE.Direccion);

            cmd.Parameters.AddWithValue("@ref_telefono", referenteCE.Telefono);
            cmd.Parameters.AddWithValue("@ref_movil", referenteCE.Movil);
            cmd.Parameters.AddWithValue("@ref_correoPerso", referenteCE.Correo);
            cmd.Parameters.AddWithValue("@ref_Dni", referenteCE.Dni);

            cmd.ExecuteNonQuery();
            cnx.Close();
        }

        //ALUMNO
        public void insertarAlumno(AlumnoCE alumnoCE)
        {
            ConexionCD conexionCD = new ConexionCD();
            SqlConnection cnx = conexionCD.ConexionToBD();
            cnx.Open();

            SqlCommand cmd = new SqlCommand("sp_insertarAlumno", cnx);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlParameter sql = new SqlParameter();
            cmd.Parameters.AddWithValue("@alu_Dni", alumnoCE.Dni);
            cmd.Parameters.AddWithValue("@alu_Nombre", alumnoCE.Nombre);
            cmd.Parameters.AddWithValue("@alu_Apellido", alumnoCE.Apellido);
            cmd.Parameters.AddWithValue("@alu_FechaNacimiento", alumnoCE.FechaNac);
            cmd.Parameters.AddWithValue("@alu_Observaciones ", alumnoCE.Observaciones);
            cmd.Parameters.AddWithValue("@apo_Dni", alumnoCE.ApoderadoDNI);
            cmd.Parameters.AddWithValue("@ref_Dni", alumnoCE.ReferenteDNI);
            cmd.Parameters.AddWithValue("@alu_Estado", alumnoCE.Estado);

            cmd.ExecuteNonQuery();

            cnx.Close();
        }

        public void actualizarAlumno(AlumnoCE alumnoCE)
        {
            ConexionCD conexionCD = new ConexionCD();
            SqlConnection cnx = conexionCD.ConexionToBD();
            cnx.Open();

            SqlCommand cmd = cnx.CreateCommand();

            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "UPDATE alumno SET alu_Nombre=@alu_Nombre, alu_Apellido=@alu_apellido, alu_FechaNacimiento=@alu_FechaNacimiento,"
                + "alu_Observaciones=@alu_Observaciones, apo_Dni=@apo_Dni, ref_Dni=@ref_Dni, alu_Estado=@alu_Estado WHERE alu_Id=@alu_Id";

            cmd.Parameters.AddWithValue("@alu_Nombre", alumnoCE.Nombre);
            cmd.Parameters.AddWithValue("@alu_Apellido", alumnoCE.Apellido);
            cmd.Parameters.AddWithValue("@alu_FechaNacimineto", alumnoCE.FechaNac);
            cmd.Parameters.AddWithValue("@alu_Observaciones ", alumnoCE.Observaciones);
            cmd.Parameters.AddWithValue("@apo_Dni", alumnoCE.ApoderadoDNI);
            cmd.Parameters.AddWithValue("@ref_Dni", alumnoCE.ReferenteDNI);
            cmd.Parameters.AddWithValue("@alu_Estado", alumnoCE.Estado);
            cmd.Parameters.AddWithValue("@alu_Id", alumnoCE.Id);

            cmd.ExecuteNonQuery();
            cnx.Close();
        }

        public AlumnoCE buscarDniAlu(string dniBuscar)
        {
            ConexionCD conexionCD = new ConexionCD();
            SqlConnection cnx = conexionCD.ConexionToBD();
            cnx.Open();

            SqlCommand cmd = cnx.CreateCommand();

            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "SELECT * FROM alumno WHERE alu_Dni=@alu_Dni";
            cmd.Parameters.AddWithValue("@alu_Dni", dniBuscar);

            SqlDataReader drAlumno = cmd.ExecuteReader();
            string id;
            string dni;
            string nombre;
            string apellido;
            DateTime fechaNacimiento;
            string observaciones;
            string apoDni;
            string refDni;
            string estado;
            if (drAlumno.Read())
            {
                id = drAlumno["alu_Id"].ToString();
                dni = drAlumno["alu_Dni"].ToString();
                nombre = drAlumno["alu_Nombre"].ToString();
                apellido = drAlumno["alu_Apellido"].ToString();
                fechaNacimiento = Convert.ToDateTime(drAlumno["alu_FechaNacimiento"].ToString());
                observaciones = drAlumno["alu_Observaciones"].ToString();
                apoDni = drAlumno["apo_Dni"].ToString();
                refDni = drAlumno["ref_Dni"].ToString();
                estado = drAlumno["alu_Estado"].ToString();
            }
            else
            {
                id = "";
                dni = "";
                nombre = "";
                apellido = "";
                fechaNacimiento = Convert.ToDateTime("");
                observaciones = "";
                apoDni = "";
                refDni = "";
                estado = "";
            }

            cnx.Close();

            AlumnoCE alumnoCE = new AlumnoCE(id, dni, nombre, apellido, fechaNacimiento, observaciones, apoDni, refDni, estado);
            
            return alumnoCE;
        }

        public List<AlumnoCE> buscarNomAlu(string aluNombre)
        {
            ConexionCD conexionCD = new ConexionCD();
            SqlConnection cnx = conexionCD.ConexionToBD();
            cnx.Open();

            SqlCommand cmd = cnx.CreateCommand();

            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM alumno WHERE alu_Nombre LIKE '%' + @alu_Nombre + '%' ";
            cmd.Parameters.AddWithValue("@alu_Nombre", aluNombre);

            SqlDataReader drAlumno = cmd.ExecuteReader();
            string id;
            string dni;
            string nombre;
            string apellido;
            DateTime fechaNacimiento;
            string observaciones;
            string apoDni;
            string refDni;
            string estado;

            List<AlumnoCE> lisAlumnos = new List<AlumnoCE>();
            while (drAlumno.Read())
            {
                id = drAlumno["alu_Id"].ToString();
                dni = drAlumno["alu_Dni"].ToString();
                nombre = drAlumno["alu_Nombre"].ToString();
                apellido = drAlumno["alu_Apellido"].ToString();
                fechaNacimiento = Convert.ToDateTime(drAlumno["alu_FechaNacimiento"].ToString());
                observaciones = drAlumno["alu_Observaciones"].ToString();
                apoDni = drAlumno["apo_Dni"].ToString();
                refDni = drAlumno["ref_Dni"].ToString();
                estado = drAlumno["alu_Estado"].ToString();

                AlumnoCE alumnoCE = new AlumnoCE(id, dni, nombre, apellido, fechaNacimiento, observaciones, apoDni, refDni, estado);
                lisAlumnos.Add(alumnoCE);
            }

            cnx.Close();

            return lisAlumnos; 
        }

        //PROFESOR
        public void insertarProfesor(ProfesorCE profesorCE)
        {
            ConexionCD conexionCD = new ConexionCD();
            SqlConnection cnx = conexionCD.ConexionToBD();
            cnx.Open();

            SqlCommand cmd = new SqlCommand("sp_insertarProfesor", cnx);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlParameter sql = new SqlParameter();
            cmd.Parameters.AddWithValue("@pro_Dni", profesorCE.Dni);
            cmd.Parameters.AddWithValue("@pro_Nombre", profesorCE.Nombre);
            cmd.Parameters.AddWithValue("@pro_Apellido", profesorCE.Apellido);
            cmd.Parameters.AddWithValue("@pro_FechaNacimiento", profesorCE.FechaNac);
            cmd.Parameters.AddWithValue("@pro_Telefono ", profesorCE.Telefono);
            cmd.Parameters.AddWithValue("@pro_Movil", profesorCE.Movil);
            cmd.Parameters.AddWithValue("@pro_Direccion", profesorCE.Direccion);
            cmd.Parameters.AddWithValue("@pro_CorreoPersonal", profesorCE.CorreoPersonal);
            cmd.Parameters.AddWithValue("@pro_FechaIngreso", profesorCE.FechaIngreso);
            cmd.Parameters.AddWithValue("@pro_Clave", profesorCE.Clave);
            cmd.Parameters.AddWithValue("@pro_Estado", profesorCE.Estado);

            cmd.ExecuteNonQuery();

            cnx.Close();
        }

        public void eliminarProfesor(ProfesorCE profesorCE)
        {

            ConexionCD conexionCD = new ConexionCD();
            SqlConnection cnx = conexionCD.ConexionToBD();
            cnx.Open();

            SqlCommand cmd = cnx.CreateCommand();

            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "DELETE FROM profesor WHERE pro_Id=@pro_Id";
            cmd.Parameters.AddWithValue("@pro_Id", profesorCE.Id);

            cmd.ExecuteNonQuery();

            cnx.Close();
        }

        public void actualizarProfesor(ProfesorCE profesorCE)
        {
            ConexionCD conexionCD = new ConexionCD();
            SqlConnection cnx = conexionCD.ConexionToBD();
            cnx.Open();

            SqlCommand cmd = cnx.CreateCommand();

            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "UPDATE profesor SET pro_Dni=@pro_dni, pro_Nombre=@pro_nombre, pro_Apellido=@pro_apellido,pro_FechaNacimiento=@pro_FechaNacimiento,"
                + "pro_Telefono=@pro_Telefono, pro_Movil=@pro_Movil, pro_Direccion=@pro_Direccion, pro_CorreoPersonal=@pro_CorreoPersonal, "
                + "pro_CorreoInstitucional=@pro_CorreoInstitucional,pro_FechaIngreso=@pro_FechaIngreso,pro_Usuario=@pro_Usuario"
                + "pro_Clave=@pro_Clave, pro_Estado=@pro_Estado"
                  + "WHERE pro_Id=@pro_Id";
            cmd.Parameters.AddWithValue("@pro_dni", profesorCE.Dni);
            cmd.Parameters.AddWithValue("@pro_nombre", profesorCE.Nombre);
            cmd.Parameters.AddWithValue("@pro_apellido", profesorCE.Apellido);
            cmd.Parameters.AddWithValue("@pro_FechaNacimiento", profesorCE.FechaNac);
            cmd.Parameters.AddWithValue("@pro_Telefono ", profesorCE.Telefono);
            cmd.Parameters.AddWithValue("@pro_Movil ", profesorCE.Movil);
            cmd.Parameters.AddWithValue("@pro_Direccion", profesorCE.Direccion);
            cmd.Parameters.AddWithValue("@pro_CorreoPersonal", profesorCE.CorreoPersonal);
            cmd.Parameters.AddWithValue("@pro_CorreoInstitucional", profesorCE.CorreoIntitucional);
            cmd.Parameters.AddWithValue("@pro_FechaIngreso", profesorCE.FechaIngreso);
            cmd.Parameters.AddWithValue("@pro_Usuario", profesorCE.Usuario);
            cmd.Parameters.AddWithValue("@pro_Clave", profesorCE.Clave);
            cmd.Parameters.AddWithValue("@pro_Clave", profesorCE.Clave);
            cmd.Parameters.AddWithValue("@pro_Estado", profesorCE.Estado);

            cmd.ExecuteNonQuery();

            cnx.Close();
        }

        public List<ProfesorCE> buscarNombreprofe(string nameProfe)
        {
            ConexionCD conexionCD = new ConexionCD();
            SqlConnection cnx = conexionCD.ConexionToBD();
            cnx.Open();

            SqlCommand cmd = cnx.CreateCommand();

            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM profesor WHERE pro_Nombre LIKE '%' + @pro_Nombre+ '%' ";
            cmd.Parameters.AddWithValue("@pro_Nombre", nameProfe);

            SqlDataReader drProfesor = cmd.ExecuteReader();
            string id;
            string dni;
            string nombre;
            string apellido;
            DateTime fechaNacimiento;
            string telefono;
            string movil;
            string direccion;
            string correoPersonal;
            string correoInstitucional;
            DateTime fechaIngreso;
            string usuario;
            string clave;
            string estado;

            List<ProfesorCE> lisProf = new List<ProfesorCE>();
            while (drProfesor.Read())
            {
                id = drProfesor["pro_Id"].ToString();
                dni = drProfesor["pro_Dni"].ToString();
                nombre = drProfesor["pro_Nombre"].ToString();
                apellido = drProfesor["pro_Apellido"].ToString();
                fechaNacimiento = Convert.ToDateTime(drProfesor["pro_FechaNacimiento"].ToString());
                telefono = drProfesor["pro_Telefono"].ToString();
                movil = drProfesor["pro_Movil"].ToString();
                direccion = drProfesor["pro_Direccion"].ToString();
                correoPersonal = drProfesor["pro_CorreoPersonal"].ToString();
                correoInstitucional = drProfesor["pro_CorreoInstitucional"].ToString();
                fechaIngreso = Convert.ToDateTime(drProfesor["pro_FechaIngreso"].ToString());
                usuario = drProfesor["pro_Usuario"].ToString();
                clave = drProfesor["pro_Clave"].ToString();
                estado = drProfesor["pro_Estado"].ToString();

                ProfesorCE profesorCE = new ProfesorCE(id, dni, nombre, apellido, fechaNacimiento, telefono, movil, direccion, correoPersonal,
                correoInstitucional, fechaIngreso, usuario, clave, estado);

                lisProf.Add(profesorCE);
            }

            cnx.Close();

            return lisProf;
        }

        public ProfesorCE buscarIdpofe(string idprofe)
        {
            ConexionCD conexionCD = new ConexionCD();
            SqlConnection cnx = conexionCD.ConexionToBD();
            cnx.Open();

            SqlCommand cmd = cnx.CreateCommand();

            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "SELECT * FROM profesor WHERE pro_Id = @pro_Id";
            cmd.Parameters.AddWithValue("@pro_Id", idprofe);

            SqlDataReader drProfe = cmd.ExecuteReader();

            string id;
            string dni;
            string nombre;
            string apellido;
            DateTime fechaNacimiento;
            string telefono;
            string movil;
            string direccion;
            string correoPersonal;
            string correoInstitucional;
            DateTime fechaIngreso;
            string usuario;
            string clave;
            string estado;

            if (drProfe.Read())
            {
                id = drProfe["pro_Id"].ToString();
                dni = drProfe["pro_Dni"].ToString();
                nombre = drProfe["pro_Nombre"].ToString();
                apellido = drProfe["pro_Apellido"].ToString();
                fechaNacimiento = Convert.ToDateTime(drProfe["pro_FechaNacimiento"].ToString());
                telefono = drProfe["pro_Telefono"].ToString();
                movil = drProfe["pro_Movil"].ToString();
                direccion = drProfe["pro_Direccion"].ToString();
                correoPersonal = drProfe["pro_CorreoPersonal"].ToString();
                correoInstitucional = drProfe["pro_CorreoInstitucional"].ToString();
                fechaIngreso = Convert.ToDateTime(drProfe["pro_FechaIngreso"].ToString());
                usuario = drProfe["pro_Usuario"].ToString();
                clave = drProfe["pro_Clave"].ToString();
                estado = drProfe["pro_Estado"].ToString();
            }
            else
            {
                id = "";
                dni = "";
                nombre = "";
                apellido = "";
                fechaNacimiento = Convert.ToDateTime("");
                telefono = "";
                movil = "";
                direccion = "";
                correoPersonal = "";
                correoInstitucional = "";
                fechaIngreso = Convert.ToDateTime("");
                usuario = "";
                clave = "";
                estado = "";
            }
            cnx.Close();

            ProfesorCE profesorCE = new ProfesorCE(id, dni, nombre, apellido, fechaNacimiento, telefono, movil, direccion, correoPersonal,
            correoInstitucional, fechaIngreso, usuario, clave, estado);

            return profesorCE;
        }
    }
}
