﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using System.Data;

using CapaEntidad;

namespace CapaDatos
{
    public class RegistroNotasCD
    {
        public RegistroNotasCE buscarRegistro(string idGrupo, string idArea)
        {
            ConexionCD conexionCD = new ConexionCD();
            SqlConnection cnx = conexionCD.ConexionToBD();
            cnx.Open();

            SqlCommand cmd = cnx.CreateCommand();

            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "SELECT * FROM registroNotas  where gru_Id = @gru_Id AND are_Id = @are_Id ";
            cmd.Parameters.AddWithValue("@gru_Id", idGrupo);
            cmd.Parameters.AddWithValue("@are_Id", idArea);

            SqlDataReader drRegistro = cmd.ExecuteReader();

            string id;
            string gru_Id;
            string are_Id;

            if (drRegistro.Read())
            {
                id = drRegistro["reg_id"].ToString();
                gru_Id = drRegistro["gru_Id"].ToString();
                are_Id = drRegistro["are_Id"].ToString();
            }
            else
            {
                id = "";
                gru_Id = "";
                are_Id = "";
                cnx.Close();
            }

            RegistroNotasCE registroNotasCE = new RegistroNotasCE(id, gru_Id, are_Id);

            return registroNotasCE;
        }
    }
}
