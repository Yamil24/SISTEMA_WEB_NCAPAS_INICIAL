﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidad
{
    public class HorarioCE
    {
        //PROPIEDADES
        private string id;
        private string nombre;
        private string gruId;

        //ENCAPSULADOS
        public string Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        public string GruId
        {
            get { return gruId; }
            set { gruId = value; }
        }

        //CONSTRUCTORES
        public HorarioCE() { }
        public HorarioCE(string id, string nombre, string gruId)
        {
            this.id = id;
            this.nombre = nombre;
            this.gruId = gruId;
        }
    }
}
