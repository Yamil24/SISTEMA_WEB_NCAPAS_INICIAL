﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidad
{
    public class ProgramaCurricularCE
    {
        //PROPIEDADES
        private string proCurId;//programa curricular
        private string lecId;//año electivo id
        private string nivId;//nivel id

        //ENCAPSULADOS
        public string ProCurId
        {
            get { return proCurId; }
            set { proCurId = value; }
        }

        public string LecId
        {
            get { return lecId; }
            set { lecId = value; }
        }
        public string NivId
        {
            get { return nivId; }
            set { nivId = value; }
        }

        //CONSTRUCTORES
        public ProgramaCurricularCE() { }
        public ProgramaCurricularCE(string proCurId, string lecId, string nivId)
        {
            this.proCurId = proCurId;
            this.lecId = lecId;
            this.nivId = nivId;
        }
    }
}
