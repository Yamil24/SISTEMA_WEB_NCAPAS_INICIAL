﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidad
{
    public class MatriculaCE
    {
        //PROPIEDADES
        private string id;
        private DateTime fechaRegistro;
        private string aluID;
        private string gruId;

        //ENCAPSULADOS
        public string Id
        {
            get { return id; }
            set { id = value; }
        }
        public DateTime FechaRegistro
        {
            get { return fechaRegistro; }
            set { fechaRegistro = value; }
        }

        public string AluId
        {
            get { return aluID; }
            set { aluID = value; }
        }
        public string GruId
        {
            get { return gruId; }
            set { gruId = value; }
        }

        //CONSTRUCTORES
        public MatriculaCE() { }
        public MatriculaCE(string id, DateTime fechaRegistro, string aluID, string gruId)
        {
            this.id = id;
            this.fechaRegistro = fechaRegistro;
            this.aluID = aluID;
            this.gruId = gruId;
        }
    }
}
