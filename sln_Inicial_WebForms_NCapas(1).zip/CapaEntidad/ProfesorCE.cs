﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidad
{
    public class ProfesorCE
    {
        //PROPIEDADES
        private string id;
        private string dni;
        private string nombre;
        private string apellido;
        private DateTime fechaNac;
        private string telefono;
        private string movil;
        private string direccion;
        private string correoPersonal;
        private string correoInstitucional;
        private DateTime fechaIngreso;
        private string usuario;
        private string clave;
        private string estado;

        //ENCAPSULADOS
        public string Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Dni
        {
            get { return dni; }
            set { dni = value; }
        }

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }
        public string Apellido
        {
            get { return apellido; }
            set { apellido = value; }
        }

        public DateTime FechaNac
        {
            get { return fechaNac; }
            set { fechaNac = value; }
        }
        public string Telefono
        {
            get { return telefono; }
            set { telefono = value; }
        }

        public string Movil
        {
            get { return movil; }
            set { movil = value; }
        }

        public string Direccion
        {
            get { return direccion; }
            set { direccion = value; }
        }
        public string CorreoPersonal
        {
            get { return correoPersonal; }
            set { correoPersonal = value; }
        }
        public string CorreoIntitucional
        {
            get { return correoInstitucional; }
            set { correoInstitucional = value; }
        }
        public DateTime FechaIngreso
        {
            get { return fechaIngreso; }
            set { fechaIngreso = value; }
        }
        public string Usuario
        {
            get { return usuario; }
            set { usuario = value; }
        }
        public string Clave
        {
            get { return clave; }
            set { clave = value; }
        }

        public string Estado
        {
            get { return estado; }
            set { estado = value; }
        }

        //CONSTRUCTORES
        public ProfesorCE() { }
        public ProfesorCE(string id, string dni, string nombre, string apellido, DateTime fechaNac, string telefono, string movil, string direccion, string correoPersonal, string correoInstitucional, DateTime fechaIngreso, string usuario, string clave, string estado)
        {
            this.id = id;
            this.dni = dni;
            this.nombre = nombre;
            this.apellido = apellido;
            this.fechaNac = fechaNac;
            this.telefono = telefono;
            this.movil = movil;
            this.direccion = direccion;
            this.correoPersonal = correoPersonal;
            this.correoInstitucional = correoInstitucional;
            this.fechaIngreso = fechaIngreso;
            this.usuario = usuario;
            this.clave = clave;
            this.estado = estado;
        }
    }
}
