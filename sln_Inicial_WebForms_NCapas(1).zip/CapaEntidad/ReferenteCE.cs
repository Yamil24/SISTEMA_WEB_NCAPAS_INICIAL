﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidad
{
    public class ReferenteCE
    {
        //PROPIEDADES
        private string dni;
        private string nombre;
        private string apellido;
        private DateTime fechaNac;
        private string direccion;
        private string telefono;
        private string movil;
        private string correo;

        //ENCAPSULADOS
        public string Dni
        {
            get { return dni; }
            set { dni = value; }
        }
        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }
        public string Apellido
        {
            get { return apellido; }
            set { apellido = value; }
        }
        public DateTime FechaNac
        {
            get { return fechaNac; }
            set { fechaNac = value; }
        }
        public string Direccion
        {
            get { return direccion; }
            set { direccion = value; }
        }

        public string Telefono
        {
            get { return telefono; }
            set { telefono = value; }
        }

        public string Movil
        {
            get { return movil; }
            set { movil = value; }
        }
        public string Correo
        {
            get { return correo; }
            set { correo = value; }
        }

        //CONSTRUCTORES
        public ReferenteCE() { }
        public ReferenteCE(string dni, string nombre, string apellido, DateTime fechaNac, string direccion, string telefono, string movil, string correo)
        {
            this.dni = dni;
            this.nombre = nombre;
            this.apellido = apellido;
            this.fechaNac = fechaNac;
            this.direccion = direccion;
            this.telefono = telefono;
            this.movil = movil;
            this.correo = correo;
        }
    }
}
