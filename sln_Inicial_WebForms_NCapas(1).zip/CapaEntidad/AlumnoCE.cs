﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidad
{
    public class AlumnoCE
    {
        //PROPIEDADES
        private string id;
        private string dni;
        private string nombre;
        private string apellido;
        private DateTime fechaNac;
        private string observaciones;
        private string apoderadoDNI;
        private string referenteDNI;
        private string estado;


        //ENCAPSULADOS
        public string Id
        {
            get { return id; }
            set { id = value; }

        }

        public string Dni
        {
            get { return dni; }
            set { dni = value; }
        }

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }
        public string Apellido
        {
            get { return apellido; }
            set { apellido = value; }
        }
        public DateTime FechaNac
        {
            get { return fechaNac; }
            set { fechaNac = value; }
        }

        public string Observaciones
        {
            get { return observaciones; }
            set { observaciones = value; }
        }
        public string ApoderadoDNI
        {
            get { return apoderadoDNI; }
            set { apoderadoDNI = value; }
        }
        public string ReferenteDNI
        {
            get { return referenteDNI; }
            set { referenteDNI = value; }
        }
        public string Estado
        {
            get { return estado; }
            set { estado = value; }
        }

        //CONSTRUCTORES
        public AlumnoCE() { }

        public AlumnoCE(string id, string dni, string nombre, string apellido, DateTime fechaNac, string observaciones, string apoderadoDNI, string referenteDNI, string estado)
        {
            this.id = id;
            this.dni = dni;
            this.nombre = nombre;
            this.apellido = apellido;
            this.fechaNac = fechaNac;
            this.observaciones = observaciones;
            this.apoderadoDNI = apoderadoDNI;
            this.referenteDNI = referenteDNI;
            this.estado = estado;
        }
    }
}
