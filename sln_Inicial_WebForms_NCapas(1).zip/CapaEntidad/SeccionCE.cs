﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidad
{
    public class SeccionCE
    {
        //PROPIEDADES
        private string id;
        private string nombre;
        private int capMax; //capacidad maxima

        //ENCAPSULADOS
        public string Id
        {
            get { return id; }
            set { id = value; }
        }
        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }
        public int CapMax
        {
            get { return capMax; }
            set { capMax = value; }
        }

        //CONSTRUCTORES
        public SeccionCE() { }
        public SeccionCE(string id, string nombre, int capMax)
        {
            this.id = id;
            this.nombre = nombre;
            this.capMax = capMax;
        }
    }
}
