﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidad
{
    public class DetalleGrupoCE
    {
        //PROPIEDADES
        private string gruId;
        private string matId; //matricula id

        //ENCAPSULADOS
        public string GruId
        {
            get { return gruId; }
            set { gruId = value; }
        }
        public string MatId
        {
            get { return matId; }
            set { matId = value; }
        }

        //CONSTRUCTORES
        public DetalleGrupoCE() { }

        public DetalleGrupoCE(string gruId, string matId)
        {
            this.gruId = gruId;
            this.matId = matId;
        }
    }
}
