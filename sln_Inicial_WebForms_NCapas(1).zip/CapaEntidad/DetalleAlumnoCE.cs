﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidad
{
    public class DetalleAlumnoCE
    {
        //PROPIEDADES
        private string habilidadesEspeciales;   //Si o No
        private string tipoHabilidad;
        private string observaciones;
        private string aluId; //id del alumno

        //ENCAPSULADOS
        public string HabilidadesEspeciales
        {
            get { return habilidadesEspeciales; }
            set { habilidadesEspeciales = value; }
        }

        public string TipoHabilidad
        {
            get { return tipoHabilidad; }
            set { tipoHabilidad = value; }
        }
        public string Observaciones
        {
            get { return observaciones; }
            set { observaciones = value; }
        }
        public string AluId
        {
            get { return aluId; }
            set { aluId = value; }
        }

        //CONSTRUCTORES
        public DetalleAlumnoCE() { }
        public DetalleAlumnoCE(string habilidadesEspeciales, string tipoHabilidad, string observaciones, string aluId)
        {
            this.habilidadesEspeciales = habilidadesEspeciales;
            this.tipoHabilidad = tipoHabilidad;
            this.observaciones = observaciones;
            this.aluId = aluId;
        }
    }
}
