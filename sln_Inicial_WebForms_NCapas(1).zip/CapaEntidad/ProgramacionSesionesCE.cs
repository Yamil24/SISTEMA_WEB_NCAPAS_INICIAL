﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidad
{
    public class ProgramacionSesionesCE
    {
        //PROPIEDADES
        private string horId;
        private string areId;
        private string horaInicio;
        private string horaFin;

        //ENCAPSULADOS
        public string HorId
        {
            get { return horId; }
            set { horId = value; }
        }
        public string AreId
        {
            get { return areId; }
            set { areId = value; }
        }
        public string HoraInicio
        {
            get { return horaInicio; }
            set { horaInicio = value; }
        }
        public string HoraFin
        {
            get { return horaFin; }
            set { horaFin = value; }
        }

        //CONSTRUCTORES
        public ProgramacionSesionesCE() { }
        public ProgramacionSesionesCE(string horId, string areId, string horaInicio, string horaFin)
        {
            this.horId = horId;
            this.areId = areId;
            this.horaInicio = horaInicio;
            this.horaFin = horaFin;
        }
    }
}
