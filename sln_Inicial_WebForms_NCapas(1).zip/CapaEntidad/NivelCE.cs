﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidad
{
    public class NivelCE
    {
        //PROPIEDADES
        private string id;
        private string nombre;

        //ENCAPSULADOS
        public string Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        //CONSTRUCTORES
        public NivelCE() { }
        public NivelCE(string id, string nombre)
        {
            this.id = id;
            this.nombre = nombre;
        }
    }
}
