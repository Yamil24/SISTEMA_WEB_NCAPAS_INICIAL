﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidad
{
    public class AñoLectivoCE
    {
        //PROPIEDADES
        private string id;
        private DateTime inicio;
        private DateTime fin;

        //ENCAPSULADOS
        public string Id
        {
            get { return id; }
            set { id = value; }
        }
        public DateTime Inicio
        {
            get { return inicio; }
            set { inicio = value; }
        }
        public DateTime Fin
        {
            get { return fin; }
            set { fin = value; }
        }

        //CONSTRUCTORES
        public AñoLectivoCE() { }
        public AñoLectivoCE(string id, DateTime inicio, DateTime fin)
        {
            this.id = id;
            this.inicio = inicio;
            this.fin = fin;
        }
    }
}
