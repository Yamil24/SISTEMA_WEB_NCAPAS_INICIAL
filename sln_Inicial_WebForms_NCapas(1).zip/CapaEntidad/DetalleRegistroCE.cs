﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidad
{
    public class DetalleRegistroCE
    {
        //PROPIEDADES
        private string drId;
        private string regId;
        private string aluId;
        private double drUnidad1;
        private double drUnidad2;
        private double drUnidad3;
        private double drUnidad4;
        private double promedioFinal;
        private string calificacion;
        private string observacion;

        //ENCAPSULADOS
        public string DrId
        {
            get { return drId; }
            set { drId = value; }
        }

        public string RegId
        {
            get { return regId; }
            set { regId = value; }
        }

        public string AluId
        {
            get { return aluId; }
            set { aluId = value; }
        }

        public Double DrUnidad1
        {
            get { return drUnidad1; }
            set { drUnidad1 = value; }
        }

        public Double DrUnidad2
        {
            get { return drUnidad2; }
            set { drUnidad2 = value; }
        }

        public double DrUnidad3
        {
            get { return drUnidad3; }
            set { drUnidad3 = value; }
        }

        public double DrUnidad4
        {
            get { return drUnidad4; }
            set { drUnidad4 = value; }
        }

        public Double PromedioFinal
        {
            get { return promedioFinal; }
            set { promedioFinal = value; }
        }

        public String Calificacion
        {
            get { return calificacion; }
            set { calificacion = value; }
        }

        public string Observacion
        {
            get { return observacion; }
            set { observacion = value; }
        }

        //CONSTRUCTORES
        public DetalleRegistroCE() { }
        public DetalleRegistroCE(string drId, string regId, string aluId, double drUnidad1, double drUnidad2, double drUnidad3, double drUnidad4, double promedioFinal, string calificacion, string observacion)
        {
            this.drId = drId;
            this.regId = regId;
            this.aluId = aluId;
            this.drUnidad1 = drUnidad1;
            this.drUnidad2 = drUnidad2;
            this.drUnidad3 = drUnidad3;
            this.drUnidad4 = drUnidad4;
            this.promedioFinal = promedioFinal;
            this.calificacion = calificacion;
            this.observacion = observacion;
        }
    }
}
