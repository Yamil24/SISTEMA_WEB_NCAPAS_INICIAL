﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidad
{
    public class DetalleProgramaCE
    {
        //PROPIEDADES
        private string progCurricularId;
        private string areId;

        //ENCAPSULADOS
        public string ProgCurricularId
        {
            get { return progCurricularId; }
            set { progCurricularId = value; }
        }
        public string AreId
        {
            get { return areId; }
            set { areId = value; }
        }

        //CONSTRUCTORES
        public DetalleProgramaCE() { }

        public DetalleProgramaCE(string progCurricularId, string areId)
        {
            this.progCurricularId = progCurricularId;
            this.areId = areId;
        }
    }
}
