﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidad
{
    public class RegistroNotasCE
    {
        //PROPIEDADES
        private string regId;
        private string gruId;
        private string areId;

        //ENCAPSULADOS
        public string RegId
        {
            get { return regId; }
            set { regId = value; }
        }
        public string GruId
        {
            get { return gruId; }
            set { gruId = value; }
        }
        public string AreId
        {
            get { return areId; }
            set { areId = value; }
        }

        //CONSTRUCTORES
        public RegistroNotasCE() { }
        public RegistroNotasCE(string regId, string gruId, string areId)
        {
            this.regId = regId;
            this.gruId = gruId;
            this.areId = areId;
        }
    }
}
