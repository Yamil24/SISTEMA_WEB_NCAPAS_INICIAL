﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidad
{
    public class GrupoRegistroCE
    {
        //PROPIEDADES
        private string gru_Id;
        private string are_Id;
        private string alu_Id;
        private string alu_Nombre;
        private string alu_Apellido;
        private decimal dr_Unidad1;
        private decimal dr_Unidad2;
        private decimal dr_Unidad3;
        private decimal dr_Unidad4;

        //ENCAPSULADOS
        public string Gru_Id
        {
            get { return gru_Id; }
            set { gru_Id = value; }
        }
        public string Are_Id
        {
            get { return are_Id; }
            set { are_Id = value; }
        }
        public string Alu_Id
        {
            get { return alu_Id; }
            set { alu_Id = value; }
        }
        public string Alu_Nombre
        {
            get { return alu_Nombre; }
            set { alu_Nombre = value; }
        }
        public string Alu_Apellido
        {
            get { return alu_Apellido; }
            set { alu_Apellido = value; }
        }
        public decimal Dr_Unidad1
        {
            get { return dr_Unidad1; }
            set { dr_Unidad1 = value; }
        }
        public decimal Dr_Unidad2
        {
            get { return dr_Unidad2; }
            set { dr_Unidad2 = value; }
        }
        public decimal Dr_Unidad3
        {
            get { return dr_Unidad3; }
            set { dr_Unidad3 = value; }
        }
        public decimal Dr_Unidad4
        {
            get { return dr_Unidad4; }
            set { dr_Unidad4 = value; }
        }

        //CONSTRUCTORES
        public GrupoRegistroCE() { }

        public GrupoRegistroCE(string gru_Id, string are_Id, string aluId, string alu_Nombre, string alu_Apellido, decimal drUnidad1, decimal drUnidad2, decimal drUnidad3, decimal drUnidad4)
        {
            this.gru_Id = gru_Id;
            this.are_Id = are_Id;
            this.alu_Id = aluId;
            this.alu_Nombre = alu_Nombre;
            this.alu_Apellido = alu_Apellido;
            this.dr_Unidad1 = drUnidad1;
            this.dr_Unidad2 = drUnidad2;
            this.dr_Unidad3 = drUnidad3;
            this.dr_Unidad4 = drUnidad4;
        }
    }
}
