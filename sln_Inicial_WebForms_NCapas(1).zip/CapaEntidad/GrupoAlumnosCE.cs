﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidad
{
    public class GrupoAlumnosCE
    {
        //PROPIEDADES
        private string gruId; //grupo id
        private string nivId; //nivel id
        private string secId; //seccion id
        private string proId; //profesor id
        private DateTime lecId; //año electivo

        //ENCAPSULADOS
        public string GruId
        {
            get { return gruId; }
            set { gruId = value; }
        }

        public string NivId
        {
            get { return nivId; }
            set { nivId = value; }
        }

        public string SecId
        {
            get { return secId; }
            set { secId = value; }
        }

        public string ProId
        {
            get { return proId; }
            set { proId = value; }
        }

        public DateTime LecId
        {
            get { return lecId; }
            set { lecId = value; }
        }

        //CONSTRUCTORES
        public GrupoAlumnosCE(){}
        public GrupoAlumnosCE(string gruId, string nivId, string secId, string proId, DateTime lecId)
        {
            this.gruId = gruId;
            this.nivId = nivId;
            this.secId = secId;
            this.proId = proId;
            this.lecId = lecId;
        }
    }
}
