﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CapaDatos;

namespace CapaNegocios
{
    public class ApoderadoUsuarioCN
    {
        public bool LoguearAlumno(string usuarioIngresado, string claveIngresada)
        {
            AlumnoUsuarioCD alumnoUsuarioCD = new AlumnoUsuarioCD();
            bool loguear = alumnoUsuarioCD.LoguearAlumno(usuarioIngresado, claveIngresada);
            return loguear;
        }
    }
}
