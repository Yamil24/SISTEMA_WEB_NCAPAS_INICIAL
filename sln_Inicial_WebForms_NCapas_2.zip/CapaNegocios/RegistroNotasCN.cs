﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CapaEntidad;
using CapaDatos;

namespace CapaNegocios
{
    public class RegistroNotasCN
    {
        public RegistroNotasCE buscarRegistro(string idGrupo, string idArea)
        {
            RegistroNotasCD registroNotasCD = new RegistroNotasCD();
            RegistroNotasCE registroNotasCE = registroNotasCD.buscarRegistro(idGrupo, idArea);

            return registroNotasCE;
        }
    }
}
