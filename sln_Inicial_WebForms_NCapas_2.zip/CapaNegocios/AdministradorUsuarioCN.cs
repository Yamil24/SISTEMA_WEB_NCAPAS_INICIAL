﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CapaDatos;
using CapaEntidad;

namespace CapaNegocios
{
    public class AdministradorUsuarioCN
    {
        public bool LoguearAdministrador(string usuarioIngresado, string claveIngresada)
        {
            AdministradorUsuarioCD adm = new AdministradorUsuarioCD();
            bool loguear = adm.LoguearAdministrador(usuarioIngresado, claveIngresada);
            return loguear;
        }

        //REFERENTE
        public void insertarReferente(ReferenteCE referenteCE)
        {
            AdministradorUsuarioCD adm = new AdministradorUsuarioCD();
            adm.insertarReferente(referenteCE);
        }

        public void actualizarReferente(ReferenteCE referenteCE)
        {
            AdministradorUsuarioCD adm = new AdministradorUsuarioCD();
            adm.actualizarReferente(referenteCE);
        }
        public void eliminarReferente(ReferenteCE referenteCE)
        {
            AdministradorUsuarioCD adm = new AdministradorUsuarioCD();
            adm.eliminarReferente(referenteCE);
        }
        public List<ReferenteCE> buscarNombreferente(string desBuscar)
        {
            AdministradorUsuarioCD adm = new AdministradorUsuarioCD();
            List<ReferenteCE> listaReferente = adm.buscarNombReferente(desBuscar);
            return listaReferente;
        }

        //APODERADO
        public void insertarApoderado(ApoderadoCE apoderadoCE)
        {
            AdministradorUsuarioCD adm = new AdministradorUsuarioCD();
            adm.insertarApoderado(apoderadoCE);
        }

        public void actualizarApoderado(ApoderadoCE apoderadoCE)
        {
            AdministradorUsuarioCD adm = new AdministradorUsuarioCD();
            adm.actualizarApoderado(apoderadoCE);
        }
        public void eliminarApoderado(ApoderadoCE apoderadoCE)
        {
            AdministradorUsuarioCD adm = new AdministradorUsuarioCD();
            adm.eliminarApoderado(apoderadoCE);
        }
        public List<ApoderadoCE> buscarbyNombreApoderado(string desBuscar)
        {
            AdministradorUsuarioCD adm = new AdministradorUsuarioCD();
            List<ApoderadoCE> listaApoderado = adm.buscarbyNombreApoderado(desBuscar);
            return listaApoderado;
        }

        //PROFESOR
        public void insertarProfesor(ProfesorCE profesorCE)
        {
            AdministradorUsuarioCD adm = new AdministradorUsuarioCD();
            adm.insertarProfesor(profesorCE);
        }
        public void actualizarProfesor(ProfesorCE profesorCE)
        {
            AdministradorUsuarioCD adm = new AdministradorUsuarioCD();
            adm.actualizarProfesor(profesorCE);
        }
        public void eliminarProfesor(ProfesorCE profesorCE)
        {
            AdministradorUsuarioCD adm = new AdministradorUsuarioCD();
            adm.eliminarProfesor(profesorCE);
        }
        public List<ProfesorCE> buscarNombreprofe(string nombre)
        {
            AdministradorUsuarioCD adm = new AdministradorUsuarioCD();
            List<ProfesorCE> listaProfesor = adm.buscarNombreprofe(nombre);
            return listaProfesor;
        }

        //ALUMNO
        public void insertarAlumno(AlumnoCE alumnoCE)
        {
            AdministradorUsuarioCD adm = new AdministradorUsuarioCD();
            adm.insertarAlumno(alumnoCE);
        }

        public void actualizarAlumno(AlumnoCE alumnoCE)
        {
            AdministradorUsuarioCD adm = new AdministradorUsuarioCD();
            adm.actualizarAlumno(alumnoCE);
        }

        public AlumnoCE buscarDniAlu(string dniBuscar)
        {
            AdministradorUsuarioCD adm = new AdministradorUsuarioCD();
            AlumnoCE alumnoCE = adm.buscarDniAlu(dniBuscar);
            return alumnoCE;
        }
        public List<AlumnoCE> buscarNomAlumno(string desBuscar)
        {
            AdministradorUsuarioCD adm = new AdministradorUsuarioCD();
            List<AlumnoCE> listaAlumnos = adm.buscarNomAlu(desBuscar);
            return listaAlumnos;
        }

    }
}
