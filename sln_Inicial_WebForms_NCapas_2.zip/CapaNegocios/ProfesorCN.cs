﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CapaEntidad;
using CapaDatos;

namespace CapaNegocios
{
    public class ProfesorCN
    {
        public bool LoguearProfesor(string usuarioIngresado, string claveIngresada)
        {
            ProfesorCD profesorCD = new ProfesorCD();
            bool loguear = profesorCD.LoguearProfesor(usuarioIngresado, claveIngresada);
            return loguear;
        }
        public List<GrupoRegistroCE> listarRegistro(string grupoId, string areaId)
        {
            ProfesorCD profesorCD = new ProfesorCD();
            List<GrupoRegistroCE> listaGrupoRegistro = profesorCD.listarRegistro(grupoId, areaId);
            return listaGrupoRegistro;
        }
        public void insertarDetalleRegistro(DetalleRegistroCE detalleRegistroCE)
        {
            ProfesorCD profesorCD = new ProfesorCD();
            profesorCD.insertarDetalleRegistro(detalleRegistroCE);
        }
        public void actualizarRegistro(DetalleRegistroCE detalleRegistroCE)
        {
            ProfesorCD profesorCD = new ProfesorCD();
            profesorCD.actualizarRegistro(detalleRegistroCE);
        }
    }
}
