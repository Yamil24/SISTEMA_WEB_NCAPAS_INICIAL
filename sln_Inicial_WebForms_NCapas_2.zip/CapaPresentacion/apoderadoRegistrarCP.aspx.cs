﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using CapaEntidad;
using CapaNegocios;

namespace CapaPresentacion
{
    public partial class apoderadoRegistrarCP : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string dni = txtDni.Text;
            string nombre = txtNombre.Text;
            string apellido = txtApellido.Text;
            DateTime fechanaciminete = Convert.ToDateTime(txtfecNac.Text);
            string direccion = txtDireccion.Text;
            string telefono = txtTelefono.Text;
            string movil = txtMovil.Text;
            string correopersonal = txtCorrPersonal.Text;
            string clave = txtClave.Text;

            ApoderadoCE apoderadoCE = new ApoderadoCE(dni, nombre, apellido, fechanaciminete, direccion, telefono, movil, correopersonal, "", clave);
            AdministradorUsuarioCN administradorUsuarioCN = new AdministradorUsuarioCN();
            administradorUsuarioCN.insertarApoderado(apoderadoCE);
        }
    }
}