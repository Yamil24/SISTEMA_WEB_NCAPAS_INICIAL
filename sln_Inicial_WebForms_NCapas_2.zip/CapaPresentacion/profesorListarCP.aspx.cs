﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using CapaEntidad;
using CapaNegocios;

namespace CapaPresentacion
{
    public partial class profesorListarCP : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        private void resetControl()
        {
            txtId.Text = "0";
            txtDni.Text = "0";
            txtNombre.Text = "";
            txtApellidos.Text = "";
            txtFecNac.Text = "yyyy/mm/dd";
            txtDireccion.Text = "";
            txtTelefono.Text = "0";
            txtMovil.Text = "0";
            txtCorreo.Text = "";
            txtFecIng.Text = "yyyy/mm/dd";
            txtUsuario.Text = "";
            txtClave.Text = "";
            txtEstado.Text = "";

            gvProfesor.SelectedIndex = -1;
            gvProfesor.DataSource = "";
            gvProfesor.DataBind();
        }

        private void buscarProfesor()
        {
            string valorBuscado = txtValorBuscado.Text;

            AdministradorUsuarioCN administradorUsuarioCN = new AdministradorUsuarioCN();

            List<ProfesorCE> listaProfesor = administradorUsuarioCN.buscarNombreprofe(valorBuscado);

            gvProfesor.DataSource = listaProfesor;
            gvProfesor.DataBind();
        }

        protected void btnBuscar_Click(object sender, EventArgs e)
        {
            buscarProfesor();
        }

        protected void botGuardar_Click1(object sender, EventArgs e)
        {
            string id = txtId.Text;
            string dni = txtDni.Text;
            string nombre = txtNombre.Text;
            string apellidos = txtApellidos.Text;
            DateTime fecNac = Convert.ToDateTime(txtFecNac.Text);
            string direccion = txtDireccion.Text;
            string telefono = txtTelefono.Text;
            string movil = txtMovil.Text;
            string correoPersonal = txtCorreo.Text;
            string correoInstitucional = "";
            DateTime fecIng = Convert.ToDateTime(txtFecIng.Text);
            string usurio = txtUsuario.Text;
            string clave = txtClave.Text;
            string estado = txtEstado.Text;

            ProfesorCE profesorCE = new ProfesorCE(id, dni, nombre, apellidos, fecNac, telefono, movil, direccion, correoPersonal, correoInstitucional, fecIng, usurio, clave, estado);

            AdministradorUsuarioCN adm = new AdministradorUsuarioCN();

            adm.actualizarProfesor(profesorCE);

            resetControl();
        }

        protected void gvProfesor_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow fila = gvProfesor.SelectedRow;

            txtId.Text = fila.Cells[0].Text;
            txtDni.Text = fila.Cells[1].Text;
            txtNombre.Text = fila.Cells[2].Text;
            txtApellidos.Text = fila.Cells[3].Text;
            txtFecNac.Text = fila.Cells[4].Text;
            txtTelefono.Text = fila.Cells[5].Text;
            txtMovil.Text = fila.Cells[6].Text;
            txtDireccion.Text = fila.Cells[7].Text;
            txtCorreo.Text = fila.Cells[8].Text;
            txtFecIng.Text = fila.Cells[9].Text;
            txtUsuario.Text = fila.Cells[10].Text;
            txtClave.Text = fila.Cells[11].Text;
            txtEstado.Text = fila.Cells[12].Text;
        }
    }
}