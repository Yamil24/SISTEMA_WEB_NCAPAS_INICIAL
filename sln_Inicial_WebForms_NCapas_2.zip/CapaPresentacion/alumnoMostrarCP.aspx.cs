﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using CapaEntidad;
using CapaNegocios;

namespace CapaPresentacion
{
    public partial class alumnoMostrarCP : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        private void buscarAlumno()
        {
            string valorBuscado = txtValorBuscado.Text;

            AdministradorUsuarioCN administradorUsuarioCN = new AdministradorUsuarioCN();

            List<AlumnoCE> listaAlumno = administradorUsuarioCN.buscarNomAlumno(valorBuscado);

            gvAlumno.DataSource = listaAlumno;

            gvAlumno.DataBind();

        }

        protected void btnBuscar_Click(object sender, EventArgs e)
        {
            buscarAlumno();
        }
    }
}