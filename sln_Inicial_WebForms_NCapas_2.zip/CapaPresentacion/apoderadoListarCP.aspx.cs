﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using CapaEntidad;
using CapaNegocios;

namespace CapaPresentacion
{
    public partial class apoderadoListarCP : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        private void resetControl()
        {
            txtDni.Text = "0";
            txtNombre.Text = "";
            txtApellidos.Text = "";
            txtFecNac.Text = "yyyy/mm/dd";
            txtDireccion.Text = "";
            txtTelefono.Text = "0";
            txtMovil.Text = "0";
            txtCorreo.Text = "";
            txtUsuario.Text = "";
            txtClave.Text = "";

            gvAPODERADO.SelectedIndex = -1;
            gvAPODERADO.DataSource = "";
            gvAPODERADO.DataBind();
        }

        private void buscarApoderado()
        {
            string valorBuscado = txtValorBuscado.Text;

            AdministradorUsuarioCN administradorUsuarioCN = new AdministradorUsuarioCN();
            List<ApoderadoCE> listaApoderado = administradorUsuarioCN.buscarbyNombreApoderado(valorBuscado);

            gvAPODERADO.DataSource = listaApoderado;
            gvAPODERADO.DataBind();
        }

        protected void btnBuscar_Click(object sender, EventArgs e)
        {
            buscarApoderado();
        }

        protected void botGuardar_Click1(object sender, EventArgs e)
        {
            string dni = txtDni.Text;
            string nombre = txtNombre.Text;
            string apellidos = txtApellidos.Text;
            DateTime fecNac = Convert.ToDateTime(txtFecNac.Text);
            string direccion = txtDireccion.Text;
            string telefono = txtTelefono.Text;
            string movil = txtMovil.Text;
            string correoPersonal = txtCorreo.Text;
            string usurio = txtUsuario.Text;
            string clave = txtClave.Text;


            ApoderadoCE apoderadoCE = new ApoderadoCE(dni, nombre, apellidos, fecNac, direccion, telefono, movil, correoPersonal, usurio, clave);

            AdministradorUsuarioCN adm = new AdministradorUsuarioCN();

            adm.actualizarApoderado(apoderadoCE);

            resetControl();
        }

        protected void gvProducto_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow fila = gvAPODERADO.SelectedRow;

            txtDni.Text = fila.Cells[0].Text;
            txtNombre.Text = fila.Cells[1].Text;
            txtApellidos.Text = fila.Cells[2].Text;
            txtFecNac.Text = fila.Cells[3].Text;
            txtDireccion.Text = fila.Cells[4].Text;
            txtTelefono.Text = fila.Cells[5].Text;
            txtMovil.Text = fila.Cells[6].Text;
            txtCorreo.Text = fila.Cells[7].Text;
            txtUsuario.Text = fila.Cells[8].Text;
            txtClave.Text = fila.Cells[9].Text;
        }
    }
}