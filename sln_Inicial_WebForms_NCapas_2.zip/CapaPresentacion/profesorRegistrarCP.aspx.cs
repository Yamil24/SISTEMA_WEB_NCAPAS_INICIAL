﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using CapaEntidad;
using CapaNegocios;

namespace CapaPresentacion
{
    public partial class profesorRegistrarCP : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string dni = txtDni.Text;
            string nombre = txtNombre.Text;
            string apellido = txtApellido.Text;
            DateTime fecNac = Convert.ToDateTime(txtfecNac.Text);
            string telefono = txtTelefono.Text;
            string movil = txtMovil.Text;
            string direccion = txtDireccion.Text;
            string correo = txtCorrPersonal.Text;
            DateTime fecIngreso = Convert.ToDateTime(txtfecIngreso.Text);
            string clave = txtClave.Text;
            string estado = txtEstado.Text;

            ProfesorCE profesorCE = new ProfesorCE("", dni, nombre, apellido, fecNac, telefono, movil, direccion, correo, "", fecIngreso, "", clave, estado);
            AdministradorUsuarioCN administradorUsuarioCN = new AdministradorUsuarioCN();
            administradorUsuarioCN.insertarProfesor(profesorCE);
        }
    }
}