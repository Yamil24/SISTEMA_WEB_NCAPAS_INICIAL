﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using CapaEntidad;
using CapaNegocios;

namespace CapaPresentacion
{
    public partial class referenteListarCP : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        private void resetControl()
        {
            txtDni.Text = "0";
            txtNombre.Text = "";
            txtApellidos.Text = "";
            txtFecNac.Text = "yyyy/mm/dd";
            txtDireccion.Text = "";
            txtTelefono.Text = "0";
            txtMovil.Text = "0";
            txtCorreo.Text = "";

            gvReferente.SelectedIndex = -1;
            gvReferente.DataSource = "";
            gvReferente.DataBind();
        }

        private void buscarReferente()
        {

            string valorBuscado = txtValorBuscado.Text;

            AdministradorUsuarioCN administradorUsuarioCN = new AdministradorUsuarioCN();

            List<ReferenteCE> listaReferente = administradorUsuarioCN.buscarNombreferente(valorBuscado);

            gvReferente.DataSource = listaReferente;
            gvReferente.DataBind();
        }

        protected void btnBuscar_Click(object sender, EventArgs e)
        {
            buscarReferente();
        }

        protected void botGuardar_Click1(object sender, EventArgs e)
        {
            string dni = txtDni.Text;
            string nombre = txtNombre.Text;
            string apellidos = txtApellidos.Text;
            DateTime fecNac = Convert.ToDateTime(txtFecNac.Text);
            string direccion = txtDireccion.Text;
            string telefono = txtTelefono.Text;
            string movil = txtMovil.Text;
            string correoPersonal = txtCorreo.Text;

            ReferenteCE referenteCE = new ReferenteCE(dni, nombre, apellidos, fecNac, direccion, telefono, movil, correoPersonal);

            //Instanciar un AdministradorCN
            AdministradorUsuarioCN adm = new AdministradorUsuarioCN();

            adm.actualizarReferente(referenteCE);

            resetControl();
        }

        protected void gvReferente_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow fila = gvReferente.SelectedRow;

            txtDni.Text = fila.Cells[0].Text;
            txtNombre.Text = fila.Cells[1].Text;
            txtApellidos.Text = fila.Cells[2].Text;
            txtFecNac.Text = fila.Cells[3].Text;
            txtDireccion.Text = fila.Cells[4].Text;
            txtTelefono.Text = fila.Cells[5].Text;
            txtMovil.Text = fila.Cells[6].Text;
            txtCorreo.Text = fila.Cells[7].Text;
        }
    }
}