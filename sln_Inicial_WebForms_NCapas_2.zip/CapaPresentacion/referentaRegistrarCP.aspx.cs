﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using CapaEntidad;
using CapaNegocios;

namespace CapaPresentacion
{
    public partial class referentaRegistrarCP : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string dni = txtDni.Text;
            string nombre = txtNombre.Text;
            string apellido = txtApellido.Text;
            DateTime fechanacimientp = Convert.ToDateTime(txtfecNac.Text);
            string direccion = txtDireccion.Text;
            string telefono = txtTelefono.Text;
            string movil = txtMovil.Text;
            string correo = txtCorrPersonal.Text;

            ReferenteCE referenteCE = new ReferenteCE(dni, nombre, apellido, fechanacimientp, direccion, telefono, movil, correo);
            AdministradorUsuarioCN administradorUsuarioCN = new AdministradorUsuarioCN();
            administradorUsuarioCN.insertarReferente(referenteCE);
        }
    }
}