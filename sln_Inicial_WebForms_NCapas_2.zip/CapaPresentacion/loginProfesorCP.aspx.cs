﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using CapaNegocios;
using CapaEntidad;

namespace CapaPresentacion
{
    public partial class loginProfesor : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string usuarioIngresado = txtUsuario.Text;
            string claveIngresada = txtClave.Text;

            ProfesorCN profesorCN = new ProfesorCN();
            bool loguear = profesorCN.LoguearProfesor(usuarioIngresado, claveIngresada);

            if (loguear == true)
            {
                Response.Redirect("IndexProfesorCP.aspx?usu=" + usuarioIngresado);
            }
        }
    }
}