﻿$('#inicio').on('click', function () {
    $('html, body').animate({ scrollTop: 0 }, 1000);
    //Inicio
    $('#inicio2').css("background", "#20f707");
    $('#inicio2').css("color", "white");
    //Acerca de
    $('#acercade2').css("background", "none");
    $('#acercade2').css("color", "#1bb014");
    //Servicios
    $('#servicios2').css("background", "none");
    $('#servicios2').css("color", "#1bb014");
    //Trabajos
    $('#trabajos2').css("background", "none");
    $('#trabajos2').css("color", "#1bb014");
})

$('#acercade').on('click', function () {
    $('html, body').animate({ scrollTop: 500 }, 1000);
    //Inicio
    $('#inicio2').css("background", "none");
    $('#inicio2').css("color", "#1bb014");
    //Acerca de
    $('#acercade2').css("background", "#20f707");
    $('#acercade2').css("color", "white");
    //Servicios
    $('#servicios2').css("background", "none");
    $('#servicios2').css("color", "#1bb014");
    //Trabajos
    $('#trabajos2').css("background", "none");
    $('#trabajos2').css("color", "#1bb014");
})

$('#servicios').on('click', function () {
    $('html, body').animate({ scrollTop: 1000 }, 1000);
    //Inicio
    $('#inicio2').css("background", "none");
    $('#inicio2').css("color", "#1bb014");
    //Acerca de
    $('#acercade2').css("background", "none");
    $('#acercade2').css("color", "#1bb014");
    //Servicios
    $('#servicios2').css("background", "#20f707");
    $('#servicios2').css("color", "white");
    //Trabajos
    $('#trabajos2').css("background", "none");
    $('#trabajos2').css("color", "#1bb014");

})

$('#trabajos').on('click', function () {
    $('html, body').animate({ scrollTop: 1500 }, 1000);
    //Inicio
    $('#inicio2').css("background", "none");
    $('#inicio2').css("color", "#1bb014");
    //Acerca de
    $('#acercade2').css("background", "none");
    $('#acercade2').css("color", "#1bb014");
    //Servicios
    $('#servicios2').css("background", "none");
    $('#servicios2').css("color", "#1bb014");
    //Trabajos
    $('#trabajos2').css("background", "#20f707");
    $('#trabajos2').css("color", "white");
})