﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using CapaEntidad;
using CapaNegocios;

namespace CapaPresentacion
{
    public partial class alumnoRegistrar : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string dni = txtDni.Text;
            string nombre = txtNombre.Text;
            string apellido = txtApellido.Text;
            DateTime fechanaciminete = Convert.ToDateTime(txtfecNac.Text);
            string observacion = txtObservacion.Text;
            string dniApo = txtDniApoderado.Text;
            string dniRef = txtDniReferente.Text;
            string estado = txtEstado.Text;


            AlumnoCE alumnoCE = new AlumnoCE("", dni, nombre, apellido, fechanaciminete, observacion, dniApo, dniRef, estado);

            AdministradorUsuarioCN administradorUsuarioCN = new AdministradorUsuarioCN();
            administradorUsuarioCN.insertarAlumno(alumnoCE);
        }
    }
}