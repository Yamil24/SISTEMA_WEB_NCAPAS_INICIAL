﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using CapaNegocios;

namespace CapaPresentacion
{
    public partial class loginApoderado : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLoguear_Click(object sender, EventArgs e)
        {
            string usuarioIngresado = txtUsuario.Text;
            string claveIngresada = txtClave.Text;

            ApoderadoUsuarioCN apoderadoUsuarioCN = new ApoderadoUsuarioCN();
            bool loguear = apoderadoUsuarioCN.LoguearAlumno(usuarioIngresado, claveIngresada);

            if (loguear == true)
            {
                Response.Redirect("IndexApoderadoCP.aspx?usu=" + usuarioIngresado);
            }
        }
    }
}