﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;

using CapaEntidad;
using CapaNegocios;

namespace CapaPresentacion
{
    public partial class profesorRegistrarNotas : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ddlGrupo.Items.Add("100");
            ddlGrupo.Items.Add("101");

            ddlArea.Items.Add("50");
            ddlArea.Items.Add("51");
            ddlArea.Items.Add("52");
            ddlArea.Items.Add("53");
        }

        protected void btnBuscar_Click(object sender, EventArgs e)
        {
            ProfesorCN profesorCN = new ProfesorCN();
            string areaId = ddlArea.SelectedValue;
            string grupoId = ddlGrupo.SelectedValue;

            List<GrupoRegistroCE> listaGrupoRegistro = profesorCN.listarRegistro(grupoId, areaId);

            gvRegistro.DataSource = listaGrupoRegistro;
            gvRegistro.DataBind();
        }

        protected void gvRegistro_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow fila = gvRegistro.SelectedRow;
            txtId.Text = fila.Cells[0].Text;
            txtUnidad1.Text = fila.Cells[3].Text;
            txtUnidad2.Text = fila.Cells[4].Text;
            txtUnidad3.Text = fila.Cells[5].Text;
            txtUnidad4.Text = fila.Cells[6].Text;
        }

        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            string id = txtId.Text;
            string idGrupo = ddlGrupo.SelectedValue;
            string idArea = ddlArea.SelectedValue;
            double unidad1 = Convert.ToDouble(txtUnidad1.Text);
            double unidad2 = Convert.ToDouble(txtUnidad2.Text);
            double unidad3 = Convert.ToDouble(txtUnidad3.Text);
            double unidad4 = Convert.ToDouble(txtUnidad4.Text);

            RegistroNotasCN registroNotasCN = new RegistroNotasCN();
            RegistroNotasCE registroNotasCE = registroNotasCN.buscarRegistro(idGrupo, idArea);

            DetalleRegistroCE detalleRegistroCE = new DetalleRegistroCE("", registroNotasCE.RegId, id, unidad1, unidad2, unidad3, unidad4, 0, "BUENO", "APROBADO");

            ProfesorCN profesorCN = new ProfesorCN();

            profesorCN.actualizarRegistro(detalleRegistroCE);
        }
    }
}