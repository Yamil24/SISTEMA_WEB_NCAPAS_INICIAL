﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using CapaNegocios;

namespace CapaPresentacion
{
    public partial class loginAdministrador : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string usuarioIngresado = txtUsuario.Text;
            string claveIngresada = txtClave.Text;

            AdministradorUsuarioCN administradorUsuarioCN = new AdministradorUsuarioCN();
            bool loguear = administradorUsuarioCN.LoguearAdministrador(usuarioIngresado, claveIngresada);

            if (loguear == true)
            {
                Response.Redirect("IndexAdministradorCP.aspx?usu=" + usuarioIngresado);
            }
        }
    }
}