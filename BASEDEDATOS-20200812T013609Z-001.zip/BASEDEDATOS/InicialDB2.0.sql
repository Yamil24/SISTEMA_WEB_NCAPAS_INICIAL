CREATE DATABASE inicialDB;

USE inicialDB;

CREATE TABLE apoderado
(
	apo_Dni char(8) not null,
	apo_Nombre varchar(100) not null,
	apo_Apellido varchar(100) not null,
	apo_FechaNacimiento date not null,
	apo_Direccion varchar(100) not null,
	apo_Telefono varchar(9) not null,
	apo_Movil varchar(9) not null,
	apo_CorreoPersonal varchar(100),
	apo_Usuario varchar(50) not null,
	apo_Clave binary(100) not null
);
GO
CREATE TABLE referente
(
	ref_Dni char(8) not null,
	ref_Nombre varchar(100) not null,
	ref_Apellido varchar(100) not null,
	ref_FechaNacimiento date not null,
	ref_Direccion varchar(100) not null,
	ref_Telefono varchar(9) not null,
	ref_Movil varchar(9) not null,
	ref_Correo varchar(100)
);
GO
CREATE TABLE alumno
(
	alu_Id varchar(10) not null,
	alu_Dni char(8) not null,
	alu_Nombre varchar(100) not null,
	alu_Apellido varchar(100) not null,
	alu_FechaNacimiento date not null,
	alu_Observaciones char(2) not null,
	apo_Dni char(8) not null,
	ref_Dni char(8) not null,
	alu_Estado varchar(20) not null
);
GO
CREATE TABLE detalleAlumno
(
	det_HabilidadesEspeciales char(2) not null,
	det_TipoHabilidad varchar(100) not null,
	det_Observaciones varchar(200) not null,
	alu_Id varchar(10) not null
);
GO
CREATE TABLE profesor
(
	pro_Id varchar(10) not null,
	pro_Dni char(8) not null,
	pro_Nombre varchar(100) not null,
	pro_Apellido varchar(100) not null,
	pro_FechaNacimiento date not null,
	pro_Telefono varchar(9) not null,
	pro_Movil varchar(9) not null,
	pro_Direccion varchar(100) not null,
	pro_CorreoPersonal varchar(100) not null,
	pro_CorreoInstitucional varchar(100) not null,
	pro_FechaIngreso date not null,
	pro_Usuario varchar(50) not null,
	pro_Clave binary(100) not null,
	pro_Estado varchar(20) not null
);
GO
CREATE TABLE a�oLectivo
(
	lec_Id char(4) not null,
	lec_FechaInicio date not null,
	lec_FechaFin date not null
);
GO
CREATE TABLE area
(
	are_Id char(5) not null,
	are_Nombre varchar(50) not null
);
GO
CREATE TABLE nivel
(
	niv_Id char(5) not null,
	niv_Nombre varchar(50) not null
);
GO
CREATE TABLE seccion
(
	sec_Id char(5) not null,
	sec_Nombre varchar(50) not null,
	sec_CapacidadMaxima int not null
);
GO
CREATE TABLE grupoAlumnos
(
	gru_Id varchar(10) not null,
	niv_Id char(5) not null,
	sec_Id char(5) not null,
	pro_Id varchar(10) not null,
	lec_Id char(4) not null
);
GO
CREATE TABLE matricula
(
	mat_Id varchar(10) not null,
	mat_FechaRegistro date not null,
	alu_Id varchar(10) not null,
	gru_Id varchar(10) not null
);
GO
CREATE TABLE horario
(
	hor_Id char(5) not null,
	hor_Nombe varchar(50) not null,
	gru_Id varchar(10) not null
);
GO
CREATE TABLE programacionSesiones
(
	hor_Id char(5) not null,
	are_Id char(5) not null,
	ps_HoraInicio varchar(8) not null,
	ps_HoraFin varchar(8) not null
);
GO
CREATE TABLE detalleGrupo
(
	gru_Id varchar(10) not null,
	mat_Id varchar(10) not null,
);
GO
CREATE TABLE programaCurricular
(
	pc_Id varchar(10) not null,
	lec_Id char(4) not null,
	niv_Id char(5) not null,
);
GO
CREATE TABLE detallePrograma
(
	pc_Id varchar(10) not null,
	are_Id char(5) not null,
);
GO
CREATE TABLE registroNotas
(
	reg_Id varchar(10) not null,
	gru_Id varchar(10) not null,
	are_Id char(5) not null,
);
GO
CREATE TABLE detalleRegistro
(
	reg_Id varchar(10) not null,
	alu_Id varchar(10) not null,
	dr_Unidad1 decimal(4,2) not null,
	dr_Unidad2 decimal(4,2) not null,
	dr_Unidad3 decimal(4,2) not null,
	dr_Unidad4 decimal(4,2) not null,
	dr_PromedioFinal decimal(4,2) not null,
	dr_Calificacion varchar(15) not null,
	dr_Observacion varchar(15) not null
);
GO
CREATE TABLE administrador
(
	adm_Id varchar(10) not null,
	adm_Dni char(8),
	adm_Nombre varchar(100),
	adm_Apellido varchar(100),
	adm_FechaNacimiento date,
	adm_Usuario varchar(50) not null,
	adm_Clave varchar(50)
)
/*TOTAL DE TABLAS: 18*/


/*------------------------------PRIMARY KEY------------------------------*/
ALTER TABLE apoderado 
ADD CONSTRAINT pk_Apoderado PRIMARY KEY (apo_Dni);
GO
ALTER TABLE referente
ADD CONSTRAINT pk_Referente PRIMARY KEY (ref_Dni);
GO
ALTER TABLE alumno
ADD CONSTRAINT pk_Alumno PRIMARY KEY (alu_Id);
GO
ALTER TABLE profesor
ADD CONSTRAINT pk_Profesor PRIMARY KEY (pro_Id);
GO
ALTER TABLE a�oLectivo
ADD CONSTRAINT pk_Lectivo PRIMARY KEY (lec_Id);
GO
ALTER TABLE area
ADD CONSTRAINT pk_Area PRIMARY KEY (are_Id);
GO
ALTER TABLE nivel
ADD CONSTRAINT pk_Nivel PRIMARY KEY (niv_Id);
GO
ALTER TABLE seccion
ADD CONSTRAINT pk_Seccion PRIMARY KEY (sec_Id);
GO
ALTER TABLE grupoAlumnos
ADD CONSTRAINT pk_GrupoAlumnos PRIMARY KEY (gru_Id);
GO
ALTER TABLE matricula
ADD CONSTRAINT pk_Matricula PRIMARY KEY (mat_Id);
GO
ALTER TABLE horario
ADD CONSTRAINT pk_Horario PRIMARY KEY (hor_Id);
GO
ALTER TABLE programaCurricular
ADD CONSTRAINT pk_ProgramaCurricular PRIMARY KEY (pc_Id);
GO
ALTER TABLE registroNotas
ADD CONSTRAINT pk_RegistroNotas PRIMARY KEY (reg_Id);
GO
ALTER TABLE administrador
ADD CONSTRAINT pk_Administrador PRIMARY KEY (adm_Id);


/*------------------------------FOREIGN KEY------------------------------*/
ALTER TABLE alumno
ADD CONSTRAINT fk_Alumno_Apoderado FOREIGN KEY (apo_Dni)
references apoderado(apo_Dni);
GO
ALTER TABLE alumno
ADD CONSTRAINT fk_Alumno_Referente FOREIGN KEY (ref_Dni)
references referente(ref_Dni);
GO
ALTER TABLE detalleAlumno
ADD CONSTRAINT fk_DetalleAlumno_Alumno FOREIGN KEY (alu_Id)
references alumno(alu_Id);
GO
ALTER TABLE grupoAlumnos
ADD CONSTRAINT fk_GrupoAlumnos_Nivel FOREIGN KEY (niv_Id)
references nivel(niv_Id);
GO
ALTER TABLE grupoAlumnos
ADD CONSTRAINT fk_GrupoAlumnos_Seccion FOREIGN KEY (sec_Id)
references seccion(sec_Id);
GO
ALTER TABLE grupoAlumnos
ADD CONSTRAINT fk_GrupoAlumnos_Profersor FOREIGN KEY (pro_Id)
references profesor(pro_Id);
GO
ALTER TABLE grupoAlumnos
ADD CONSTRAINT fk_GrupoAlumnos_Lectivo FOREIGN KEY (lec_Id)
references a�oLectivo(lec_Id);
GO
ALTER TABLE matricula
ADD CONSTRAINT fk_Matricula_Alumno  FOREIGN KEY (alu_Id)
references alumno(alu_Id);
GO
ALTER TABLE matricula
ADD CONSTRAINT fk_Matricula_GrupoAlumnos FOREIGN KEY (gru_Id)
references grupoAlumnos(gru_Id);
GO
ALTER TABLE horario
ADD CONSTRAINT fk_Horario_GrupoAlumnos FOREIGN KEY (gru_Id)
references grupoAlumnos(gru_Id);
GO
ALTER TABLE programacionSesiones
ADD CONSTRAINT fk_ProgramacionSesiones_Horario FOREIGN KEY (hor_Id)
references horario(hor_Id);
GO
ALTER TABLE programacionSesiones
ADD CONSTRAINT fk_ProgramacionSesiones_Area FOREIGN KEY (are_Id)
references area(are_Id);
GO
ALTER TABLE detalleGrupo
ADD CONSTRAINT fk_DetalleGrupo_GrupoAlumnos FOREIGN KEY (gru_Id)
references grupoAlumnos(gru_Id);
GO
ALTER TABLE detalleGrupo
ADD CONSTRAINT fk_DetalleGrupo_Matricula FOREIGN KEY (mat_Id)
references matricula(mat_Id);
GO
ALTER TABLE programaCurricular
ADD CONSTRAINT fk_ProgramaCurricular_Lectivo FOREIGN KEY (lec_Id)
references a�oLectivo(lec_Id);
GO
ALTER TABLE programaCurricular
ADD CONSTRAINT fk_ProgramaCurricular_Nivel FOREIGN KEY (niv_Id)
references nivel(niv_Id);
GO
ALTER TABLE detallePrograma
ADD CONSTRAINT fk_DetallePrograma_ProgramaCurricular FOREIGN KEY (pc_Id)
references programaCurricular(pc_Id);
GO
ALTER TABLE detallePrograma
ADD CONSTRAINT fk_DetallePrograma_Area FOREIGN KEY (are_Id)
references area(are_Id);
GO
ALTER TABLE registroNotas
ADD CONSTRAINT fk_registroNotas_GrupoAlumnos FOREIGN KEY (gru_Id)
references grupoAlumnos(gru_Id);
GO
ALTER TABLE registroNotas
ADD CONSTRAINT fk_RegistroNotas_Area FOREIGN KEY (are_Id)
references area(are_Id);
GO
ALTER TABLE detalleRegistro
ADD CONSTRAINT fk_DetalleRegistro_RegistroNotas FOREIGN KEY (reg_Id)
references registroNotas(reg_Id);
GO
ALTER TABLE detalleRegistro
ADD CONSTRAINT fk_DetalleRegistro_Alumnno FOREIGN KEY (alu_Id)
references alumno(alu_Id);
GO


/*------------------------------RESTRICCIONES(CHECKS)------------------------------*/
ALTER TABLE apoderado
ADD CONSTRAINT chk_fnApoderado
CHECK(apo_FechaNacimiento < getdate());
GO
ALTER TABLE referente
ADD CONSTRAINT chk_fnReferente
CHECK(ref_FechaNacimiento < getdate());
GO
ALTER TABLE alumno
ADD CONSTRAINT chk_fnAlumno
CHECK(alu_FechaNacimiento < getdate());
GO
ALTER TABLE apoderado
ADD CONSTRAINT chk_edad
CHECK((Year(GETDATE()) - Year(apo_FechaNacimiento)) >=18);
GO
ALTER TABLE referente
ADD CONSTRAINT chk_edad_referente
CHECK((Year(GETDATE()) - Year(ref_FechaNacimiento)) >=18);
GO
ALTER TABLE alumno
ADD CONSTRAINT chk_edad_alumno
CHECK((Year(GETDATE()) - Year(alu_FechaNacimiento)) BETWEEN 3 AND 6);
GO
ALTER TABLE apoderado
ADD CONSTRAINT chk_correo_apoderado
CHECK(apo_CorreoPersonal like '%[@]%[.]%');
GO
ALTER TABLE referente
ADD CONSTRAINT chk_correo_referente
CHECK(ref_Correo like '%[@]%[.]%');
GO
ALTER TABLE profesor
ADD CONSTRAINT chk_correo_profesor
CHECK(pro_CorreoPersonal like '%[@]%[.]%');
GO
ALTER TABLE profesor
ADD CONSTRAINT chk_correoInstitucional_profesor
CHECK(pro_CorreoInstitucional like '%[@]%[.]%');
GO
ALTER TABLE apoderado
ADD CONSTRAINT chk_dniApoderado
CHECK(apo_Dni like '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]' and len(apo_Dni) = 8);
GO
ALTER TABLE referente
ADD CONSTRAINT chk_dniReferente
CHECK(ref_dni like '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]' and len(ref_Dni) = 8);
GO
ALTER TABLE alumno
ADD CONSTRAINT chk_dniAlumno
CHECK(alu_Dni like '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]' and len(alu_Dni) = 8);
GO
ALTER TABLE alumno
ADD CONSTRAINT chk_dniApoderado_Alumno
CHECK(apo_Dni like '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]' and len(apo_Dni) = 8);
GO
ALTER TABLE alumno
ADD CONSTRAINT chk_dniReferente_Alumno
CHECK(ref_Dni like '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]' and len(ref_Dni) = 8);
GO
ALTER TABLE profesor
ADD CONSTRAINT chk_dniProfesor
CHECK(pro_Dni like '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]' and len(pro_Dni) = 8);
GO
ALTER TABLE apoderado
ADD CONSTRAINT chk_telefonoApoderado
CHECK(apo_Telefono like '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]' and len(apo_Telefono) = 9);
GO
ALTER TABLE referente
ADD CONSTRAINT chk_telefonoReferente
CHECK(ref_Telefono like '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]' and len(ref_Telefono) = 9);
GO
ALTER TABLE profesor
ADD CONSTRAINT chk_telefonoProfesor
CHECK(pro_Telefono like '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]' and len(pro_Telefono) = 9);
GO--
ALTER TABLE apoderado
ADD CONSTRAINT chk_movilApoderado
CHECK(apo_Movil like '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]' and len(apo_Movil) = 9);
GO
ALTER TABLE referente
ADD CONSTRAINT chk_movilReferente
CHECK(ref_Movil like '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]' and len(ref_Movil) = 9);
GO
ALTER TABLE profesor
ADD CONSTRAINT chk_MovilProfesor
CHECK(pro_Movil like '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]' and len(pro_Movil) = 9);
GO
ALTER TABLE profesor
ADD CONSTRAINT chk_fecIngreso
CHECK(pro_FechaIngreso < getdate());
GO
ALTER TABLE a�oLectivo
ADD CONSTRAINT chk_controlarFechas
CHECK(lec_FechaInicio < lec_FechaFin);
GO
ALTER TABLE detalleRegistro
ADD CONSTRAINT chk_nota_Unidades_Promedio
CHECK(dr_Unidad1 BETWEEN 0 and 20 and dr_Unidad2 BETWEEN 0 and 20 and dr_Unidad3 BETWEEN 0 and 20 and 
dr_Unidad4 BETWEEN 0 and 20 and dr_PromedioFinal BETWEEN 0 and 20);
GO
ALTER TABLE detalleRegistro
ADD CONSTRAINT chk_Calificacion
CHECK(dr_Calificacion in ('EN PROGRESO','REGULAR','BUENO','MUY BUENO'));
GO
ALTER TABLE detalleRegistro
ADD CONSTRAINT chk_Observacion
CHECK(dr_Observacion in ('DESAPROBADO','APROBADO'));
GO


/*------------------------------FUNCIONES------------------------------*/

CREATE FUNCTION fun_generarUsuario(@nombre varchar(100),@apellidos varchar(100),@dni char(8))
RETURNS varchar(50) AS
BEGIN
	DECLARE @letraNombre varchar(100);
	DECLARE @apePat varchar(100);
	DECLARE @LApeMat varchar(100);
	DECLARE @DIGDNI char(8);
	DECLARE @USUARIO varchar(50);
	DECLARE @CANT int;

	SET @letraNombre = LEFT(@nombre,1);
	SET @apePat = LEFT(@apellidos,4);
	SET @DIGDNI = LEFT(@dni,4);
	SET @USUARIO = LOWER(@letraNombre+@ApePat+@DIGDNI);
	SET @CANT = (SELECT COUNT(apo_Usuario) FROM apoderado where apo_Usuario= @USUARIO);

	IF @CANT=1
	BEGIN
		SET @LApeMat = SUBSTRING(@apellidos,CHARINDEX(' ',@apellidos)+1,1);
		SET @USUARIO = LOWER(@letraNombre+@apePat+@LApeMat+@DIGDNI);
	END;

	RETURN @USUARIO;
END;

GO
/*--------------------------------------------------------------------------------------------------------*/

CREATE FUNCTION fun_generarId(@fechaNacimiento date,@dni char(8))
RETURNS VARCHAR(10) AS
BEGIN
	DECLARE @id VARCHAR(50);

	SET @id = LOWER(CONVERT(VARCHAR,(DAY(@fechaNacimiento)))+RIGHT(@dni,5));

	RETURN @id;
END;

GO
/*---------------------------------------------------------------------------------------------------*/

CREATE FUNCTION fun_generarCorreo(@nombre varchar(100),@apellidos varchar(100))
RETURNS VARCHAR(100) AS
BEGIN
	DECLARE @selectNombre VARCHAR(100);
	DECLARE @ApePat varchar(100);
	DECLARE @LApeMat varchar(100);
	DECLARE @correo VARCHAR(100);
	DECLARE @cant int;

	SET @selectNombre = LEFT(@nombre,CHARINDEX(' ',@nombre)-1);
	SET @ApePat = LEFT(@apellidos,CHARINDEX(' ',@apellidos)-1);
	SET @correo = LOWER(@selectNombre+'.'+@ApePat+'@edu.com');
	SET @CANT = (SELECT COUNT(pro_CorreoInstitucional) FROM profesor WHERE pro_CorreoInstitucional= @correo);

	IF @cant=1
	BEGIN
		SET @LApeMat = SUBSTRING(@apellidos,CHARINDEX(' ',@apellidos)+1,1);
		SET @correo = LOWER(@selectNombre+'.'+@ApePat+@LApeMat+'@edu.com');
	END;

	RETURN @correo;
END;

GO
/*---------------------------------------------------------------------------------------------------------------*/

CREATE FUNCTION fun_encriptarClave(@claveNormal varchar(100))
RETURNS BINARY(100) AS
BEGIN
	DECLARE @claveBinary binary(50);
	SET @claveBinary = HASHBYTES('SHA1',@claveNormal);
	RETURN @claveBinary;
END;

GO
/*--------------------------------------------------------------------------------------------------------*/

CREATE FUNCTION fun_promediar(@Unidad1 decimal, @Unidad2 decimal, @Unidad3 decimal, @Unidad4 decimal)
RETURNS decimal(4,2) AS
BEGIN
	DECLARE @promedio decimal(4,2);
	SET @promedio = (@Unidad1+@Unidad2+@Unidad3+@Unidad4)/4;
	RETURN @promedio;
END;

GO
/*------------------------------------------------------------------------------------------------------*/

CREATE FUNCTION fun_calificacion(@promedio decimal)
RETURNS varchar(100) AS
BEGIN

	DECLARE @calificacion varchar(100);

	IF @promedio <11
		BEGIN
			SET @calificacion = 'EN PROGRESO';
		END;
	ELSE IF @promedio>10 AND @promedio <15
		BEGIN
			SET @calificacion = 'REGULAR';
		END;
	ELSE IF @promedio>14 AND @promedio <18
		BEGIN
			SET @calificacion = 'BUENO';
		END;
	ELSE IF @promedio>17 AND @promedio <=20
		BEGIN
			SET @calificacion = 'MUY BUENO';
		END;
	
	RETURN @calificacion;
END;

GO
/*------------------------------------------------------------------------------------------------------*/

CREATE FUNCTION fun_observacion(@promedio decimal)
RETURNS varchar(100) AS
BEGIN
	DECLARE @observacion varchar(100);
	IF @promedio <11
		BEGIN
			SET @observacion = 'DESAPROBADO';
		END;
	ELSE
		BEGIN
			SET @observacion = 'APROBADO';
		END;
	
	RETURN @observacion;
END;

GO

/*------------------------------PROCEDIMIENTOS ALMACENADOS------------------------------*/

CREATE PROCEDURE sp_insertarApoderado
	@apo_Dni char(8),
	@apo_Nombre varchar(100),
	@apo_Apellido varchar(100),
	@apo_FechaNacimiento date,
	@apo_Direccion varchar(100),
	@apo_Telefono char(9),
	@apo_Movil char(9),
	@apo_CorreoPersonal varchar(100),
	@apo_Clave varchar(50)
AS
BEGIN
	INSERT INTO apoderado(apo_Dni,apo_Nombre,apo_Apellido,apo_FechaNacimiento,apo_Direccion,apo_Telefono,
	apo_Movil,apo_CorreoPersonal,apo_Usuario,apo_Clave)
	VALUES(@apo_Dni,@apo_Nombre,@apo_Apellido,@apo_FechaNacimiento,@apo_Direccion,@apo_Telefono,@apo_Movil,@apo_CorreoPersonal,
	dbo.fun_generarUsuario(@apo_Nombre,@apo_Apellido,@apo_Dni),dbo.fun_encriptarClave(@apo_Clave))
END;

GO

/*-----------------------------------------------------------------*/

CREATE PROCEDURE sp_insertarReferente
	@ref_Dni char(8),
	@ref_Nombre varchar(100),
	@ref_Apellido varchar(100),
	@ref_FechaNacimiento date,
	@ref_Direccion varchar(100),
	@ref_Telefono char(9),
	@ref_Movil char(9),
	@ref_Correo varchar(100)
AS
BEGIN
	INSERT INTO referente(ref_Dni, ref_Nombre, ref_Apellido, ref_FechaNacimiento, ref_Direccion, ref_Telefono,
	ref_Movil, ref_Correo)
	VALUES(@ref_Dni,@ref_Nombre,@ref_Apellido,@ref_FechaNacimiento,@ref_Direccion,@ref_Telefono,@ref_Movil, @ref_Correo)
END;
GO

/*-----------------------------------------------------------------*/

CREATE PROCEDURE sp_insertarAlumno
	@alu_Dni char(8),
	@alu_Nombre varchar(100),
	@alu_Apellido varchar(100),
	@alu_FechaNacimiento date,
	@alu_Observaciones char(2),
	@apo_Dni char(8),
	@ref_Dni char(8),
	@alu_Estado varchar(20)
AS
BEGIN
	INSERT INTO alumno(alu_Id, alu_Dni, alu_Nombre, alu_Apellido, alu_FechaNacimiento, alu_Observaciones, apo_Dni, ref_Dni, alu_Estado)
	VALUES(dbo.fun_generarID(@alu_FechaNacimiento,@alu_Dni),@alu_Dni,@alu_Nombre,@alu_Apellido,@alu_FechaNacimiento,
	@alu_Observaciones,@apo_Dni,@ref_Dni,@alu_Estado)
END;
GO

/*-----------------------------------------------------------------*/

CREATE PROCEDURE sp_insertarProfesor 
	@pro_Dni char(8),
	@pro_Nombre varchar(100),
	@pro_Apellido varchar(100),
	@pro_FechaNacimiento date,
	@pro_Telefono char(9),
	@pro_Movil varchar(9),
	@pro_Direccion varchar(100),
	@pro_CorreoPersonal varchar(100),
	@pro_FechaIngreso date,
	@pro_Clave varchar(100),
	@pro_Estado varchar(20)
AS
BEGIN
	INSERT INTO profesor(pro_Id, pro_Dni, pro_Nombre, pro_Apellido, pro_FechaNacimiento, pro_Telefono, pro_Movil, pro_Direccion,
	pro_CorreoPersonal, pro_CorreoInstitucional, pro_FechaIngreso, pro_Usuario, pro_Clave, pro_Estado)
	VALUES(dbo.fun_generarId(@pro_FechaNacimiento,@pro_Dni),@pro_Dni,@pro_Nombre,@pro_Apellido,@pro_FechaNacimiento,
	@pro_Telefono, @pro_Movil, @pro_Direccion, @pro_CorreoPersonal, dbo.fun_generarCorreo(@pro_Nombre,@pro_Apellido), @pro_FechaIngreso,
	dbo.fun_generarUsuario(@pro_Nombre,@pro_Apellido,@pro_Dni), dbo.FUN_encriptarClave(@pro_Clave),@pro_Estado)
END;
GO
/*-------------------------------------------------------------------------------------------------------------*/
CREATE PROCEDURE sp_LoguearAdministrador
	@adm_Usuario varchar(50),
	@adm_Clave varchar(100)

AS
BEGIN
	SELECT * FROM administrador
	WHERE adm_Usuario = @adm_Usuario AND adm_Clave = HASHBYTES('SHA1',@adm_Clave)
END;
GO
/*-------------------------------------------------------------------------------------------------------------*/
CREATE PROCEDURE sp_insertarAdministrador
	@adm_Dni char(8),
	@adm_Nombre varchar(100),
	@adm_Apellido varchar(100),
	@adm_FechaNacimiento date,
	@adm_Clave varchar(50)
AS
BEGIN
	INSERT INTO administrador
	VALUES(dbo.fun_generarId(@adm_FechaNacimiento,@adm_Dni),@adm_Dni,@adm_Nombre,@adm_Apellido,@adm_FechaNacimiento,
	dbo.fun_generarUsuario(@adm_Nombre,@adm_Apellido,@adm_Dni),dbo.fun_encriptarClave(@adm_Clave))
END;
GO
/*------------------------------VISTA REGISTRO------------------------------------------*/
CREATE VIEW vistaRegistro
AS
SELECT alu.alu_Id AS 'codigo', alu.alu_Nombre AS 'nombre', alu.alu_Apellido AS 'apellido', gruAlu.gru_Id AS 'grupoId', are.are_Id AS 'areaId', dtReg.dr_Unidad1 AS 'nota1', dtReg.dr_Unidad2 AS 'nota2', dtReg.dr_Unidad3 AS 'nota3', dtReg.dr_Unidad4 AS 'nota4'
FROM detalleRegistro dtReg INNER JOIN registroNotas reg
ON dtReg.reg_Id = reg.reg_Id INNER JOIN grupoAlumnos gruAlu
ON reg.gru_Id = gruAlu.gru_Id INNER JOIN area are
ON reg.are_Id = are.are_Id INNER JOIN alumno alu
ON dtReg.alu_Id = alu.alu_Id
GO

/*============================================ PRUEBAS DE INSERCION DE DATOS ============================================*/
INSERT INTO a�oLectivo VALUES(YEAR(GETDATE()),'2019/03/01','2019/12/01')
INSERT INTO a�oLectivo VALUES(YEAR(GETDATE()-365),'2018/03/01','2018/12/01')
INSERT INTO a�oLectivo VALUES(YEAR(GETDATE()-730),'2017/03/01','2017/12/01')

INSERT INTO nivel VALUES('100','3 A�OS');
INSERT INTO nivel VALUES('200','4 A�OS');
INSERT INTO nivel VALUES('300','5 A�OS');

INSERT INTO seccion VALUES('10','A',20)
INSERT INTO seccion VALUES('11','B',20)
INSERT INTO seccion VALUES('12','C',20)

INSERT INTO area VALUES('50','ARTE')
INSERT INTO area VALUES('51','INGLES')
INSERT INTO area VALUES('52','MATEMATICAS')
INSERT INTO area VALUES('53','LENGUAJE')

EXEC sp_insertarApoderado '10293847','LUISA MARIA','SANCHEZ CARRION','1980/01/02','Calle Magnolias N�344','014567899','987654321','luisa.sanchez@gmail.com','luisa02'
EXEC sp_insertarApoderado '10303848','LIZ MARIA','MALPARTIDA VASQUEZ','1984/06/06','Calle Orquideaz N�254','014782999','987321456','maria.06@gmail.com','maria06'
EXEC sp_insertarApoderado '10490849','CARLOS ALAN','GASCA CERRON','1985/03/20','Calle Los Robles N�254','014563699','998588123','carlos.07@gmail.com','carlos20'
EXEC sp_insertarApoderado '10593050','JOSIAS MARTIN','RIOS CEDRON','1989/08/24','Calle Amapolas N�354','014567589','965432112','josias.08@gmail.com','josias24'
EXEC sp_insertarApoderado '10699847','ANTONIO MIGUEL','SANCHEZ GUTIERREZ','1980/01/02','Calle Magnolias N�244','014567845','987654123','antonio.miguel@gmail.com','antoni0'
EXEC sp_insertarApoderado '10703848','MARIA LUZ','VASQUEZ DIAZ','1984/06/06','Calle Orquideaz N�334','014782999','987321794','maria.luz@gmail.com','marluz'
EXEC sp_insertarApoderado '10890849','ALAN ESMILDOR','CERRON FLORES','1985/03/20','Calle Los Robles N�544','014563987','998587823','alan.123@gmail.com','aldor'
EXEC sp_insertarApoderado '10993050','MARTIN JEREMI','CEDRON GOYZUETA','1989/08/24','Calle Amapolas N�324','014567123','965434512','jeremi.678@gmail.com','martincedron'
EXEC sp_insertarApoderado '11090849','RODRIGO GIORGO','FLORES HURTADO','1985/06/22','Calle Los Robles N�122','014563988','997687823','rodrigo.22@gmail.com','rodrigo'
EXEC sp_insertarApoderado '11193050','RUTH DENNIS','RAMOS TORRES','1989/09/21','Calle Amapolas N�245','014567333','999434512','ruth.21@gmail.com','ruthramos'

EXEC sp_insertarReferente '91827346','RICARDO LUIS','BELLIDO ALVARES','1990/01/25','Calle San Agustin N�122','014562345','987654321','ricardo.05@gmail.com'
EXEC sp_insertarReferente '82734612','RENE GERMAN','GARCIA MENDEZ','1987/05/22','Calle Madre Selva N�234','014567898','997654321','german.rene@gmail.com'
EXEC sp_insertarReferente '73015246','MARIA SOL','RIOS ZACONETA','1988/08/02','Calle Achirana N�256','013456789','987632178','maria.56@gmail.com'
EXEC sp_insertarReferente '73326012','FIORELLA MARIBEL','RAMIREZ BORJA','1988/06/02','Calle Las Palmeras N�345','015678912','997654456','fiore.borja@gmail.com'
EXEC sp_insertarReferente '09899847','ANTONIO RODRIGO','SANCHEZ FERNANDEZ','1980/07/02','Calle Magnolias N�284','014567826','987654133','antonoro@gmail.com'
EXEC sp_insertarReferente '09703848','LUZ RUTH','VASQUEZ SANCHEZ','1984/09/06','Calle Orquideaz N�350','014782949','987321724','luz@gmail.com'
EXEC sp_insertarReferente '09890849','ALAN GERSON','CEDRON GOYZUETA','1985/04/20','Calle Los Robles N�540','014563947','998587853','alan.goy@gmail.com'
EXEC sp_insertarReferente '09993050','GERSON JEREMI','CERRON FLORES','1989/05/24','Calle Amapolas N�320','014567143','965434522','gerson.jer@gmail.com'
EXEC sp_insertarReferente '09190849','RODRIGO JESUS','RAMOS TORRES','1985/06/22','Calle Los Robles N�120','014563948','997687833','rodrigo.ramos@gmail.com'
EXEC sp_insertarReferente '09193050','JOAS JESUS','FLORES HURTADO','1989/08/21','Calle Amapolas N�240','014567343','999434522','flores.joas@gmail.com'


EXEC sp_insertarAlumno '73045612','JAEKON SAMIR','SANCHEZ MEZA','2014/02/11','No','10293847','91827346','Activo'
EXEC sp_insertarAlumno '73593856','RICHARD GUILLERMO','MALPARTIDA LUYO','2014/03/01','No','10303848','82734612','Activo'
EXEC sp_insertarAlumno '73203856','JESSICA YARUMI','GASCA CORDOVA','2014/01/15','No','10490849','73015246','Activo'
EXEC sp_insertarAlumno '73390856','DIANA MILAGROS','RIOS ALVAREZ','2014/01/16','No','10593050','73326012','Activo'
EXEC sp_insertarAlumno '73445678','YADHIRA ANTUANETH','SANCHEZ CACERES','2014/08/16','No','10699847','09899847','Activo'
EXEC sp_insertarAlumno '73545689','PIERO ANGELO','VASQUEZ CAMPOS','2015/08/12','No','10703848','09703848','Activo'
EXEC sp_insertarAlumno '73612345','MAURICIO ESTEFANO', 'CERRON MENDOXZA','2015/07/26','No','10890849','09890849','Activo'
EXEC sp_insertarAlumno '73745689','NOEMI FIORELLA','CEDRON ROJAS','2015/08/10','No','10993050','09993050','Activo'
EXEC sp_insertarAlumno '73012322','DAYANA NICOLE','FLORES TORRES','2015/03/11','No','11090849','09190849','Activo'
EXEC sp_insertarAlumno '73322445','JORGE LUIS','RAMOS HURTADO','2015/02/10','No','11193050','09193050','Activo'

EXEC sp_insertarProfesor '09845612','RAFAELA FIORELLA','CARRASCO RIOS','1990/10/15','017654321','918273640','Calle Girasoles N�123','profesor1@gmail.com','2015/10/02','rafaelasenati','Activo';
EXEC sp_insertarProfesor '09817263','ERICKA JESENIA ','SANCHEZ VASQUEZ','1989/11/25','017004321','918003640','Calle Orquideaz N�126','profesor2@gmail.com','2015/01/01','erickasenati','Activo';

EXEC sp_insertarAdministrador'73345678', 'JOSE CARLOS', 'GARCIA GUTIERRREZ', '1982/11/05', 'SENATI'

INSERT INTO grupoAlumnos VALUES('100','300','10','1545612',YEAR(GETDATE()))
INSERT INTO grupoAlumnos VALUES('101','300','11','2517263',YEAR(GETDATE()-365))


INSERT INTO matricula values('100','2018/01/11','1145612','101')
INSERT INTO matricula values('101','2018/01/11','1503856','101')
INSERT INTO matricula values('102','2018/01/11','1503856','101')
INSERT INTO matricula values('103','2018/01/11','1690856','101')
INSERT INTO matricula values('104','2018/01/11','193856','101')
INSERT INTO matricula values('200','2019/01/11','1022445','100')
INSERT INTO matricula values('201','2019/01/11','1022445','100')
INSERT INTO matricula values('202','2019/01/11','1112322','100')
INSERT INTO matricula values('203','2019/01/11','1245689','100')
INSERT INTO matricula values('204','2019/01/11','2612345','100')

INSERT INTO horario values('10','LUNES','100')
INSERT INTO horario values('11','MARTES','100')
INSERT INTO horario values('12','MIERCOLES','100')
INSERT INTO horario values('13','JUEVES','100')
INSERT INTO horario values('14','VIERNES','100')
INSERT INTO horario values('20','LUNES','101')
INSERT INTO horario values('21','MARTES','101')
INSERT INTO horario values('22','MIERCOLES','101')
INSERT INTO horario values('23','JUEVES','101')
INSERT INTO horario values('24','VIERNES','101')

INSERT INTO programacionSesiones values('10','50','08:00','13:00')
INSERT INTO programacionSesiones values('11','51','08:00','13:00')
INSERT INTO programacionSesiones values('12','52','08:00','13:00')
INSERT INTO programacionSesiones values('13','53','08:00','13:00')
INSERT INTO programacionSesiones values('14','50','08:00','13:00')
INSERT INTO programacionSesiones values('20','50','08:00','13:00')
INSERT INTO programacionSesiones values('21','51','08:00','13:00')
INSERT INTO programacionSesiones values('22','52','08:00','13:00')
INSERT INTO programacionSesiones values('23','53','08:00','13:00')
INSERT INTO programacionSesiones values('24','50','08:00','13:00')

INSERT INTO detalleGrupo values('100','200')
INSERT INTO detalleGrupo values('100','201')
INSERT INTO detalleGrupo values('100','202')
INSERT INTO detalleGrupo values('100','203')
INSERT INTO detalleGrupo values('100','204')
INSERT INTO detalleGrupo values('101','100')
INSERT INTO detalleGrupo values('101','101')
INSERT INTO detalleGrupo values('101','102')
INSERT INTO detalleGrupo values('101','103')
INSERT INTO detalleGrupo values('101','104')

INSERT INTO programaCurricular values('PC30','2019','300')
INSERT INTO programaCurricular values('PC20','2018','300')

INSERT INTO detallePrograma values('PC20','50')
INSERT INTO detallePrograma values('PC20','51')
INSERT INTO detallePrograma values('PC20','52')
INSERT INTO detallePrograma values('PC20','53')
INSERT INTO detallePrograma values('PC30','50')
INSERT INTO detallePrograma values('PC30','51')
INSERT INTO detallePrograma values('PC30','52')
INSERT INTO detallePrograma values('PC30','53')

INSERT INTO registroNotas VALUES('1000','101','50')
INSERT INTO registroNotas VALUES('1001','101','51')
INSERT INTO registroNotas VALUES('1002','101','52')
INSERT INTO registroNotas VALUES('1003','101','53')
INSERT INTO registroNotas VALUES('2000','100','50')
INSERT INTO registroNotas VALUES('2001','100','51')
INSERT INTO registroNotas VALUES('2002','100','52')
INSERT INTO registroNotas VALUES('2003','100','53')

INSERT INTO detalleRegistro VALUES('1000','1145612',15,14,15,15,dbo.fun_promediar(15,14,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,14,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,14,15,15)))
INSERT INTO detalleRegistro VALUES('1001','1145612',15,16,15,15,dbo.fun_promediar(15,16,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,16,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,16,15,15)))
INSERT INTO detalleRegistro VALUES('1002','1145612',15,16,15,15,dbo.fun_promediar(15,16,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,16,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,16,15,15)))
INSERT INTO detalleRegistro VALUES('1003','1145612',15,16,15,15,dbo.fun_promediar(15,16,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,16,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,16,15,15)))

INSERT INTO detalleRegistro VALUES('1000','1503856',15,13,15,15,dbo.fun_promediar(15,13,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,13,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,13,15,15)))
INSERT INTO detalleRegistro VALUES('1001','1503856',15,15,15,17,dbo.fun_promediar(15,15,15,17),dbo.fun_calificacion(dbo.fun_promediar(15,15,15,17)),dbo.fun_observacion(dbo.fun_promediar(15,15,15,17)))
INSERT INTO detalleRegistro VALUES('1002','1503856',15,14,15,15,dbo.fun_promediar(15,14,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,14,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,14,15,15)))
INSERT INTO detalleRegistro VALUES('1003','1503856',15,15,15,15,dbo.fun_promediar(15,15,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,15,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,15,15,15)))

INSERT INTO detalleRegistro VALUES('1000','1645678',15,15,15,11,dbo.fun_promediar(15,15,15,11),dbo.fun_calificacion(dbo.fun_promediar(15,15,15,11)),dbo.fun_observacion(dbo.fun_promediar(15,15,15,11)))
INSERT INTO detalleRegistro VALUES('1001','1645678',15,15,15,13,dbo.fun_promediar(15,15,15,13),dbo.fun_calificacion(dbo.fun_promediar(15,15,15,13)),dbo.fun_observacion(dbo.fun_promediar(15,15,15,13)))
INSERT INTO detalleRegistro VALUES('1002','1645678',15,15,15,15,dbo.fun_promediar(15,15,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,15,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,15,15,15)))
INSERT INTO detalleRegistro VALUES('1003','1645678',15,15,15,17,dbo.fun_promediar(15,15,15,17),dbo.fun_calificacion(dbo.fun_promediar(15,15,15,17)),dbo.fun_observacion(dbo.fun_promediar(15,15,15,17)))

INSERT INTO detalleRegistro VALUES('1000','1690856',15,15,12,15,dbo.fun_promediar(15,15,12,15),dbo.fun_calificacion(dbo.fun_promediar(15,15,12,15)),dbo.fun_observacion(dbo.fun_promediar(15,15,12,15)))
INSERT INTO detalleRegistro VALUES('1001','1690856',15,15,12,15,dbo.fun_promediar(15,15,12,15),dbo.fun_calificacion(dbo.fun_promediar(15,15,12,15)),dbo.fun_observacion(dbo.fun_promediar(15,15,12,15)))
INSERT INTO detalleRegistro VALUES('1002','1690856',15,15,12,15,dbo.fun_promediar(15,15,12,15),dbo.fun_calificacion(dbo.fun_promediar(15,15,12,15)),dbo.fun_observacion(dbo.fun_promediar(15,15,12,15)))
INSERT INTO detalleRegistro VALUES('1003','1690856',15,15,12,15,dbo.fun_promediar(15,15,12,15),dbo.fun_calificacion(dbo.fun_promediar(15,15,12,15)),dbo.fun_observacion(dbo.fun_promediar(15,15,12,15)))

INSERT INTO detalleRegistro VALUES('1000','193856',15,15,15,15,dbo.fun_promediar(15,15,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,15,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,15,15,15)))
INSERT INTO detalleRegistro VALUES('1001','193856',15,15,15,15,dbo.fun_promediar(15,15,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,15,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,15,15,15)))
INSERT INTO detalleRegistro VALUES('1002','193856',15,15,15,15,dbo.fun_promediar(15,15,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,15,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,15,15,15)))
INSERT INTO detalleRegistro VALUES('1003','193856',15,15,15,15,dbo.fun_promediar(15,15,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,15,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,15,15,15)))

INSERT INTO detalleRegistro VALUES('2000','2612345',15,15,15,15,dbo.fun_promediar(15,15,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,15,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,15,15,15)))
INSERT INTO detalleRegistro VALUES('2000','2612345',15,15,15,15,dbo.fun_promediar(15,15,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,15,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,15,15,15)))
INSERT INTO detalleRegistro VALUES('2000','2612345',15,15,15,15,dbo.fun_promediar(15,15,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,15,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,15,15,15)))
INSERT INTO detalleRegistro VALUES('2000','2612345',15,15,15,15,dbo.fun_promediar(15,15,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,15,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,15,15,15)))

INSERT INTO detalleRegistro VALUES('2000','1245689',15,14,15,15,dbo.fun_promediar(15,14,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,14,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,14,15,15)))
INSERT INTO detalleRegistro VALUES('2001','1245689',15,14,15,15,dbo.fun_promediar(15,14,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,14,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,14,15,15)))
INSERT INTO detalleRegistro VALUES('2002','1245689',15,14,15,15,dbo.fun_promediar(15,14,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,14,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,14,15,15)))
INSERT INTO detalleRegistro VALUES('2003','1245689',15,14,15,15,dbo.fun_promediar(15,14,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,14,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,14,15,15)))

INSERT INTO detalleRegistro VALUES('2000','1022445',15,14,15,15,dbo.fun_promediar(15,14,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,14,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,14,15,15)))
INSERT INTO detalleRegistro VALUES('2001','1022445',15,14,15,15,dbo.fun_promediar(15,14,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,14,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,14,15,15)))
INSERT INTO detalleRegistro VALUES('2002','1022445',15,14,15,15,dbo.fun_promediar(15,14,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,14,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,14,15,15)))
INSERT INTO detalleRegistro VALUES('2003','1022445',15,14,15,15,dbo.fun_promediar(15,14,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,14,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,14,15,15)))

INSERT INTO detalleRegistro VALUES('2000','1045689',15,14,15,15,dbo.fun_promediar(15,14,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,14,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,14,15,15)))
INSERT INTO detalleRegistro VALUES('2001','1045689',15,14,15,15,dbo.fun_promediar(15,14,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,14,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,14,15,15)))
INSERT INTO detalleRegistro VALUES('2002','1045689',15,14,15,15,dbo.fun_promediar(15,14,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,14,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,14,15,15)))
INSERT INTO detalleRegistro VALUES('2003','1045689',15,14,15,15,dbo.fun_promediar(15,14,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,14,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,14,15,15)))

INSERT INTO detalleRegistro VALUES('2000','1112322',15,14,15,15,dbo.fun_promediar(15,14,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,14,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,14,15,15)))
INSERT INTO detalleRegistro VALUES('2001','1112322',15,14,15,15,dbo.fun_promediar(15,14,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,14,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,14,15,15)))
INSERT INTO detalleRegistro VALUES('2002','1112322',15,14,15,15,dbo.fun_promediar(15,14,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,14,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,14,15,15)))
INSERT INTO detalleRegistro VALUES('2003','1112322',15,14,15,15,dbo.fun_promediar(15,14,15,15),dbo.fun_calificacion(dbo.fun_promediar(15,14,15,15)),dbo.fun_observacion(dbo.fun_promediar(15,14,15,15)))



/*===============================CAMBIAR FUNCION GENERAR USUARIO==========================================*/


select dbo.fun_generarUsuario('ERICK YAMIL','FERNANDEZ JARA','78912366');
select dbo.fun_generarId('2001/05/23','78912366');
SELECT dbo.fun_generarCorreo('ERICK YAMIL','FERNANDEZ JARA');
SELECT dbo.fun_encriptarClave('1');
SELECT dbo.fun_promediar(10,05,10,20);
SELECT dbo.fun_calificacion(18);
SELECT dbo.fun_observacion(11);
EXEC sp_LoguearAdministrador 'jdasdadssds1234','SENATI'
select * from vistaRegistro where grupoId = 100 and areaId = 50

